package com.example.crosstalk.service;

import android.app.AlertDialog;
import android.app.IntentService;
import android.content.Context;
import android.content.Intent;

import com.example.crosstalk.NetEnty.ChengShiNE;
import com.example.crosstalk.NetEnty.MyUser;
import com.example.crosstalk.NetEnty.OneP;
import com.example.crosstalk.NetEnty.ThreeP;
import com.example.crosstalk.NetEnty.TwoP;
import com.example.crosstalk.util.BaseUtil;
import com.example.crosstalk.util.MBmobutil;
import com.example.crosstalk.util.TimeUtil;
import com.example.crosstalk.util.ViewMyUtil;

import java.util.List;

import cn.bmob.v3.BmobInstallationManager;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobGeoPoint;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.QueryListener;
import cn.bmob.v3.listener.SaveListener;


/**
 * An {@link IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p>
 * TODO: Customize class - update intent actions, extra parameters and static
 * helper methods.
 */
public class writeIntentService extends IntentService {
    // TODO: Rename actions, choose action names that describe tasks that this
    // IntentService can perform, e.g. ACTION_FETCH_NEW_ITEMS
    private static final String ACTION_FOO = "com.example.crosstalk.service.action.FOO";
    private static final String ACTION_BAZ = "com.example.crosstalk.service.action.BAZ";

    // TODO: Rename parameters
    private static final String EXTRA_PARAM1 = "com.example.crosstalk.service.extra.PARAM1";
    private static final String EXTRA_PARAM2 = "com.example.crosstalk.service.extra.PARAM2";
  
//    public   static  MyUser user;
    public   writeIntentService(){
        super("");
    }


    
    public  static  Context mContext;
    
 

    /**
     * Starts this service to perform action Foo with the given parameters. If
     * the service is already performing a task this action will be queued.
     *
     * @see IntentService
     */
    // TODO: Customize helper method
    public static void startActionFoo(Context context , String param1, String param2) {
        mContext=context;
       
        Intent intent = new Intent(context, writeIntentService.class);
        intent.setAction(ACTION_FOO);
        intent.putExtra(EXTRA_PARAM1, param1);
        intent.putExtra(EXTRA_PARAM2, param2);
        context.startService(intent);
    }

    /**
     * Starts this service to perform action Baz with the given parameters. If
     * the service is already performing a task this action will be queued.
     *
     * @see IntentService
     */
    // TODO: Customize helper method
    public static void startActionBaz(Context context, ThreeP param1, String param2) {
        Intent intent = new Intent(context, writeIntentService.class);
        intent.setAction(ACTION_BAZ);
        intent.putExtra(EXTRA_PARAM1, param1);
        intent.putExtra(EXTRA_PARAM2, param2);
        context.startService(intent);
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            final String action = intent.getAction();
            if (ACTION_FOO.equals(action)) {
                final String param1 = intent.getStringExtra(EXTRA_PARAM1);
                final String param2 = intent.getStringExtra(EXTRA_PARAM2);
                handleActionFoo(param1, param2);
            } else if (ACTION_BAZ.equals(action)) {
                final String param1 = intent.getStringExtra(EXTRA_PARAM1);
                final String param2 = intent.getStringExtra(EXTRA_PARAM2);
                handleActionBaz(param1, param2);
            }
        }
    }
    

    /**
     * Handle action Foo in the provided background thread with the provided
     * parameters.
     */
    private void handleActionFoo(final String param1, String param2) {
        // TODO: Handle action Foo
        final MyUser user=BmobUser.getCurrentUser(MyUser.class);
        String usergetChengShiNEObjID=user.getChengShiNEObjID();
        if(user!=null&&param1!=null){
            if(usergetChengShiNEObjID==null){
     
                BmobQuery<ChengShiNE> query = new BmobQuery<ChengShiNE>();
//查询playerName叫“比目”的数据
                query.addWhereEqualTo("username", user.getUsername());
//返回50条数据，如果不加上这条语句，默认返回10条数据
                query.setLimit(1);
//执行查询方法
                query.findObjects(new FindListener<ChengShiNE>() {
                    @Override
                    public void done(List<ChengShiNE> object, BmobException e) {
                        if(e==null){
                            // 已存在
                            if(object!=null&&object.size()==1){
                                ChengShiNE mzChengShiNE= object.get(0);
                                 doSendmsg(mzChengShiNE.getObjectId(),user,param1);
                            }else{
                                //初始化诚信
                                final ChengShiNE mChengShiNE=new  ChengShiNE();
                                mChengShiNE.setUsername(user.getUsername());
                                mChengShiNE.setPj(10);//品阶 平民
                                mChengShiNE.setH(false);//黑名单
                                if(user.getSex()==true){
                                    mChengShiNE.setNumber(41);
                                }else{
                                    mChengShiNE.setNumber(40);//诚信值
                                }
                                mChengShiNE.setSum(0);//积分
                                //添加一对一关联
                                mChengShiNE.setMyuser(user);

                                mChengShiNE.save(new SaveListener<String>() {

                                    @Override
                                    public void done(String objectId, BmobException e) {
                                        if(e==null){
                                            //toast("创建数据成功：" + objectId);
                                            user.setChengShiNEObjID(objectId);
                                            doSendmsg(objectId,user,param1);
                                        }else{
                                          //  progressDialog.setMessage("初始化用户诚信失败！="+  BaseUtil.ErrorInfoString(e.getErrorCode()));
                                            //Log.i("bmob","失败："+e.getMessage()+","+e.getErrorCode());
                                            ViewMyUtil.shwoNotifi( mContext, ""
                                                    ,  " 初始化用户诚信失败",   " 初始化用户诚信失败",   "");
                                        }
                                         
                                    }
                                });
                             
                            }

                        }else{
//                            progressDialog.setMessage("查询诚信信息失败！="+  BaseUtil.ErrorInfoString(e.getErrorCode()));
                            ViewMyUtil.shwoNotifi( mContext,  BaseUtil.ErrorInfoString(e.getErrorCode()) 
                                    ,  "查询诚信信息失败",   "查询诚信信息失败",   "");
                        }
                    }


                });
         
            }else{
                doSendmsg(usergetChengShiNEObjID,user,param1);
             
            }
      
        }else{
            ViewMyUtil.shwoNotifi( mContext, "未登录"
                    ,  " 提示！",   " 提示！",   "");
        };
      
    }

    private void doSendmsg(String usergetChengShiNEObjID, final MyUser user, final String param1) {
        BmobQuery<ChengShiNE> query = new BmobQuery<ChengShiNE>();
       final String mInstallationId=  BmobInstallationManager.getInstallationId();
        query.getObject(usergetChengShiNEObjID, new QueryListener<ChengShiNE>() {

            @Override
            public void done(ChengShiNE chengShiNE, BmobException e) {
                if(e==null){
                 
                    if(!chengShiNE.isH()){//非黑号
                        int number=  chengShiNE.getNumber();
                        if( number<27){//3下名
                            ThreeP mThreeP=new ThreeP();
                            //人物
                            mThreeP.setUsername(user.getUsername());
                            mThreeP.setNick(user.getNick());//新加
                            mThreeP.setSexflag(user.getSex());
                            mThreeP.setPj(chengShiNE.getPj());
                            mThreeP.setNumber(number);
                            //时间
                            mThreeP.setTime(TimeUtil.getTimemili());
                            //地点
                            BmobGeoPoint map=  MBmobutil.getlocation(mContext);
                            if(map!=null){
                                mThreeP.setMap(map);
                            }
                            //说了某些事
                            mThreeP.setMsg(param1);//内容
                            mThreeP.setObjps(-1);//对象 所有品阶 
                            mThreeP.setReaded(false);//是否有人读过
                            mThreeP.setInstallationId(mInstallationId);//标记自己
                            mThreeP.save(new SaveListener<String>() {

                                @Override
                                public void done(String objectId, BmobException e) {
                                    if(e==null){
                                        ViewMyUtil.shwoNotifi( mContext, "发送成功碰碰瓶"
                                                ,  "发送成功碰碰瓶",   " 发送成功碰碰瓶",   "");
                                    }else{
                                        ViewMyUtil.shwoNotifi( mContext, "发送失败！碰碰瓶"
                                                ,  " 发送失败！碰碰瓶",   " 发送失败！碰碰瓶",   "");
                                    }
                                }
                            });
                        }else if(number>=27 && number<54){//2钟鸣
                            TwoP mTwoP=new TwoP();
                            //人物
                            mTwoP.setUsername(user.getUsername());
                            mTwoP.setSexflag(user.getSex());
                            mTwoP.setNick(user.getNick());//新加
                            mTwoP.setPj(chengShiNE.getPj());
                            mTwoP.setNumber(number);
                            //时间
                            mTwoP.setTime(TimeUtil.getTimemili());
                            //地点
                            BmobGeoPoint map=  MBmobutil.getlocation(mContext);
                            if(map!=null){
                                mTwoP.setMap(map);
                            }
                            //说了某些事
                            mTwoP.setMsg(param1);//内容
                            mTwoP.setObjps(-1);//对象 所有品阶 
                            mTwoP.setReaded(false);//是否有人读过
                            mTwoP.setInstallationId(mInstallationId);//标记自己
                            mTwoP.save(new SaveListener<String>() {

                                @Override
                                public void done(String objectId, BmobException e) {
                                    if(e==null){
                                        ViewMyUtil.shwoNotifi( mContext, "发送成功碰碰瓶"
                                                ,  " 发送成功碰碰瓶",   " 发送成功碰碰瓶",   "");
                                    }else{
                                        ViewMyUtil.shwoNotifi( mContext, "发送失败！碰碰瓶"
                                                ,  "发送失败！碰碰瓶",   " 发送失败！碰碰瓶",   "");
                                    }
                                }
                            });
                        }else if(number>54){//1钟鸣
                            OneP mOneP=new OneP();
                            //人物
                            mOneP.setUsername(user.getUsername());
                            mOneP.setSexflag(user.getSex());
                            mOneP.setNick(user.getNick());//新加
                            mOneP.setPj(chengShiNE.getPj());
                            mOneP.setNumber(number);
                            //时间
                            mOneP.setTime(TimeUtil.getTimemili());
                            //地点
                            BmobGeoPoint map=  MBmobutil.getlocation(mContext);
                            if(map!=null){
                                mOneP.setMap(map);
                            }
                            //说了某些事
                            mOneP.setMsg(param1);//内容
                            mOneP.setObjps(-1);//对象 所有品阶 
                            mOneP.setReaded(false);//是否有人读过
                            mOneP.setInstallationId(mInstallationId);//标记自己
                            mOneP.save(new SaveListener<String>() {

                                @Override
                                public void done(String objectId, BmobException e) {
                                    if(e==null){
                                        ViewMyUtil.shwoNotifi( mContext, "发送成功碰碰瓶"
                                                ,  "发送成功碰碰瓶",   "发送成功碰碰瓶",   "");
                                    }else{
                                        ViewMyUtil.shwoNotifi( mContext, "发送失败！碰碰瓶"
                                                ,  " 发送失败！碰碰瓶",   "发送失败！碰碰瓶！",   "");
                                    }
                                }
                            });
                        }
                    }else{
                        // 黑号
                        ViewMyUtil.shwoNotifi( mContext, ""
                                ,  " 提示！",   "无法发送碰碰瓶你号现在处于黑名单中",   "");
                    }

                }else{
                    ViewMyUtil.shwoNotifi( mContext, "无法发送碰碰瓶"
                            ,  "查询诚信信息失败",   " 查询诚信信息失败",   "");
                }
            }


        });
    }

    private AlertDialog showCustomizeDialog(Context mContext) {
   
        final AlertDialog.Builder customizeDialog =
                new AlertDialog.Builder(mContext);
 
         customizeDialog.setTitle("提示");
        customizeDialog.setMessage("hello");
        
        final AlertDialog mAlertDialog= customizeDialog.create();
      
        mAlertDialog.setCanceledOnTouchOutside(false);
        mAlertDialog.show();
        return mAlertDialog;

    }
    /**
     * Handle action Baz in the provided background thread with the provided
     * parameters.
     */
    private void handleActionBaz(String param1, String param2) {
        // TODO: Handle action Baz
       
    }
    
     
}
