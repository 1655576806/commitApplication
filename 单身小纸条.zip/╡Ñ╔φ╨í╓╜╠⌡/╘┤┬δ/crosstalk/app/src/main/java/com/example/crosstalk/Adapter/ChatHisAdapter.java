package com.example.crosstalk.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.example.crosstalk.R;
import com.example.crosstalk.util.TimeUtil;
import com.example.crosstalk.util.ViewHolder;

import java.util.List;
import java.util.Map;

import static com.example.crosstalk.R.id.chat_his;


/**
 * Created by Administrator on 2017/9/12 0012.
 */

public class ChatHisAdapter extends SimpleAdapter {
    LayoutInflater mLayoutInflater;
    Context context;
    List<? extends Map<String, ?>> mdata;
    String[] mfrom=null;
    int[] mto=null;
    public ChatHisAdapter(LayoutInflater mLayoutInflater,Context  context, List<? extends Map<String, ?>> data, int resource, String[] from, int[] to) {
        super(context, data, resource, from, to);
        this.context=context;
        this.mLayoutInflater=mLayoutInflater;
        this.mdata=data;
        mfrom=from;
        mto=to;

    }

     

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder mViewHolder =null;
        if (mdata.size() != 0) {
            final Map<String, String> mss = (Map<String, String>) mdata
                    .get(position);
            String type = mss.get("type");
            if (type.trim().equalsIgnoreCase("1")) {
                mViewHolder = ViewHolder.get(context, convertView, R.layout.chat_item_obj_item);

            } else {
                mViewHolder = ViewHolder.get(context, convertView, R.layout.chat_item_my_item);

            }
            TextView TextView_name=(TextView) mViewHolder.findViewById(R.id.chat_item_username);
            TextView  TextView_chat_item_time=(TextView) mViewHolder.findViewById(R.id.chat_item_time);
            TextView  TextView_recentmsg=(TextView) mViewHolder.findViewById(R.id.chat_item_msg);
            TextView_name.setText(mss.get(mfrom[0]));
            if(mss.get(mfrom[1])!=null){
                Long mTime=   Long.parseLong(mss.get(mfrom[1]));
                String fomatTime= TimeUtil.getDateTimeFromMillisecond(mTime);
                TextView_chat_item_time.setText(fomatTime);
            }

            TextView_recentmsg.setText(mss.get(mfrom[2]));
             
        }else{
            
        }
       
       if(mViewHolder==null){
           return convertView;
       }else{
           return mViewHolder.getConvertView();
       }
       
 
//
//        if (mdata.size() != 0) {
//            final Map<String, String> mss = (Map<String, String>) mdata
//                    .get(position);
//          String type=  mss.get("type");
//            if(type.trim().equalsIgnoreCase("1")){
//                convertView = mLayoutInflater.inflate(R.layout.chat_item_obj_item, null);
//            }else {
//                convertView = mLayoutInflater.inflate(R.layout.chat_item_my_item, null);
//            }
//            TextView TextView_name=(TextView) convertView.findViewById(R.id.chat_item_username);
//            TextView  TextView_chat_item_time=(TextView) convertView.findViewById(R.id.chat_item_time);
//            TextView  TextView_recentmsg=(TextView) convertView.findViewById(R.id.chat_item_msg);
//         
//            TextView_name.setText(mss.get(mfrom[0]));
//            if(mss.get(mfrom[1])!=null){
//                 Long mTime=   Long.parseLong(mss.get(mfrom[1]));
//               String fomatTime= TimeUtil.getDateTimeFromMillisecond(mTime);
//                TextView_chat_item_time.setText(fomatTime);
//            }
//            
//            TextView_recentmsg.setText(mss.get(mfrom[2]));
//        }else{
//            
//        }
//        return convertView;
    }

//    public static class ViewHolder {
//        public TextView textView;
//    }
}
