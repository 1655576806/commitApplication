package com.example.crosstalk;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.crosstalk.NetEnty.MyUser;
import com.example.crosstalk.NetEnty.ThreeP;
import com.example.crosstalk.service.writeIntentService;
import com.example.crosstalk.util.Base;
import com.example.crosstalk.util.BaseUtil;
import com.example.crosstalk.util.MBmobutil;
import com.example.crosstalk.util.MapDistance;
import com.example.crosstalk.util.TimeUtil;

import org.json.JSONObject;

import cn.bmob.v3.BmobRealTimeData;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobGeoPoint;
import cn.bmob.v3.listener.ValueEventListener;

import static cn.bmob.v3.BmobUser.getCurrentUser;
import static com.example.crosstalk.R.id.btn_write;
import static com.example.crosstalk.service.writeIntentService.mContext;


public class WorldActivity extends Base implements View.OnClickListener {
    public ImageButton mImageButton;
    public Button writeButton;
    public Button readButton;
    public Button historyButton;
    ProgressDialog
            progressDialog;
    ThreeP mThreeP=null;
    BmobRealTimeData rtd = new BmobRealTimeData();
    String tableNameTwoP="TwoP";
    String tableNameOneP="OneP";
    String tableNameThreeP="ThreeP";
   
   public   Handler worldHandler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            Bundle bd = msg.getData();
            switch (bd.getInt("key")) {
                case 0:
                    showCustomizeDialog();
                    break;
                case 1:
                    mImageButton.setImageResource(R.drawable.dd_dh);
                    AnimationDrawable animationDrawable1 = (AnimationDrawable) mImageButton.getDrawable();
                    animationDrawable1.start();
                   // mImageButton.setEnabled(false);
//
//                 
//                    mImageButton.setImageResource(R.mipmap.green_pz);
                    rtd.start(new ValueEventListener() {
                        @Override
                        public void onDataChange(JSONObject data) {
                         
                          
                            //   Log.d("bmob", "("+data.optString("action")+")"+"数据："+data);
                            //BaseUtil.sendhandlermessage(baseHandler,false,0,data)
                            JSONObject objectdata=data.optJSONObject("data");
                            String objname= objectdata.optString("username");
                       
                           
                            long sendtime= objectdata.optLong("time");
                            
//                            String  dateString= TimeUtil.getSpaceTime(sendtime);
                            
                            
                            boolean readed=objectdata.optBoolean("readed");
                         
                            String minstallationId=objectdata.optString("installationId");
                            JSONObject objectmap=objectdata.optJSONObject("map");
                            Double objlongitude=0.00;
                            Double objlatitude=0.00;
                            if(objectmap!=null){
                                objlongitude=objectmap.optDouble("longitude");
                                  objlatitude=objectmap.optDouble("latitude");
                            }

                            String objid=objectdata.optString("objectId");
                           
                            int objectnumber=objectdata.optInt("number");
                          
                            boolean objsex=objectdata.optBoolean("sexflag");
                            String mNick=objectdata.optString("nick");
                           
                            String objmsg=objectdata.optString("msg");
                          
                            int objpj=objectdata.optInt("pj");
                           
                            int objps=objectdata.optInt("objps");
                            MyUser user=    getCurrentUser(MyUser.class);
                            if(readed==true){//已读  继续接听
                            
                            }else {//未读
                                if (objname != null && !objname.equalsIgnoreCase(user.getUsername())) {
                                    if(rtd.isConnected()){

                                        if(user!=null){
                                            rtd.unsubTableUpdate(tableNameTwoP );
                                        }

                                    }
                                    mThreeP=new ThreeP();
                                    mThreeP.setObjectId(objid);
                                    mThreeP.setUsername(objname);
                                    mThreeP.setNick(mNick);
                                    mThreeP.setTime(sendtime);
                                    mThreeP.setReaded(readed);
                                    mThreeP.setMap(new BmobGeoPoint(objlongitude,objlatitude));
                                    mThreeP.setNumber(objectnumber);
                                    mThreeP.setSexflag(objsex);
                                    mThreeP.setMsg(objmsg);
                                    mThreeP.setPj(objpj);
                                    mThreeP.setObjps(objps);
                                    mThreeP.setInstallationId(minstallationId);

                                    mImageButton.setImageResource(R.mipmap.green_pz);
                                    ScaleAnimation scaleAnimation = new ScaleAnimation(0,1,0,1);//x轴0倍，x轴1倍，y轴0倍，y轴1倍 
                                    scaleAnimation.setDuration(1000);
                                    mImageButton.startAnimation(scaleAnimation);

                                    mImageButton.setEnabled(true);
//                                mImageButton.setImageBitmap(null);
                                    //readButton.setEnabled(true);
                                } else{
                                }
                             
                            }
                          
                            return;
                        }

                        @Override
                        public void onConnectCompleted(Exception ex) {
                            //    Log.d("bmob", "连接成功:"+rtd.isConnected());
                            if(ex==null){
                                if(rtd.isConnected()){
                                    MyUser user=    getCurrentUser(MyUser.class);
                                    // 监听表更新
                                    if(user!=null){
                                        rtd.subTableUpdate(tableNameTwoP );
                                    }

                                }
                            }else{
                                showCustomizeDialog("异常:"+ ex.getMessage());
                                mImageButton.setImageBitmap(null);
                                readButton.setEnabled(true);
                            }
                         
                        }
                    });
//                    showCustomizeDialog();
                    break;
                case 8://write tip
                  
                            progressDialog
                                    = new ProgressDialog(mContext);
                            progressDialog.setIcon(R.mipmap.ic_launcher);
                            progressDialog.setTitle("提示！");
                            progressDialog.setMessage("未查到你的诚信信息");
                            progressDialog.show();
                            progressDialog.setCanceledOnTouchOutside(false);
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {

                    }finally {
                        progressDialog.dismiss();
                    }
      
                  break;
            }

        }
    };

    private void showCustomizeDialog(String s) {
        final AlertDialog.Builder customizeDialog =
                new AlertDialog.Builder(WorldActivity.this);
       
         customizeDialog.setTitle("提示");
          customizeDialog.setMessage(s);
        final AlertDialog mAlertDialog= customizeDialog.create();
         mAlertDialog.setCanceledOnTouchOutside(false);
        mAlertDialog.show();


    }

    private void showCustomizeDialog(final ThreeP mshowThreeP) {
      
        final String  dateString= TimeUtil.getSpaceTime(mshowThreeP.getTime());
        
        
        
        final AlertDialog.Builder normalDialog =
                new AlertDialog.Builder(WorldActivity.this);
        normalDialog.setIcon(R.mipmap.ic_launcher);
       // normalDialog.setTitle("远方的漂流瓶");
       // normalDialog.setMessage(action);
        
        final View dialogView = LayoutInflater.from(WorldActivity.this)
                .inflate(R.layout.pz_dialog_layout,null);
         normalDialog.setView(dialogView);
       final AlertDialog mAlertDialog=    normalDialog.create();
        Button  mdialog_btn_info=(Button)dialogView.findViewById(R.id.btn_info);
        final LinearLayout llone=(LinearLayout)dialogView.findViewById(R.id.ll_one);
        final LinearLayout lltwo=(LinearLayout)dialogView.findViewById(R.id.ll_two);
       
        final TextView tv_name_pz= (TextView)dialogView.findViewById(R.id.tv_name_pz);
        final  TextView tv_name_sex= (TextView)dialogView.findViewById(R.id.tv_name_sex);
        final  TextView tv_name_time= (TextView)dialogView.findViewById(R.id.tv_name_time);
        final  TextView tv_name_length= (TextView)dialogView.findViewById(R.id.tv_name_length);
        final  TextView tv_name_xj= (TextView)dialogView.findViewById(R.id.tv_name_xj);
        final  TextView tv_name_pj= (TextView)dialogView.findViewById(R.id.tv_name_pj);

      
        mdialog_btn_info.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                MyUser myUser=  BmobUser.getCurrentUser(MyUser.class);
                if(myUser.getPower()!=1){
                    
               
                lltwo.setVisibility(View.VISIBLE);
              
              //  tv_name_pz.setText("电话号码："+mshowThreeP.getUsername()+"");
                tv_name_pz.setText("昵称："+mshowThreeP.getNick());
                if(mshowThreeP.isSexflag()){
                    tv_name_sex.setText("性别：男");
                }else{
                    tv_name_sex.setText("性别：女");
                }
              
                tv_name_time.setText("发送时间："+dateString);
                String  mlenogj="";
                try {
                    BmobGeoPoint mBmobGeoPoint=  MBmobutil.getlocation(WorldActivity.this);
                    if(mshowThreeP.getMap()!=null){
                        mlenogj=MapDistance.getInstance().getLongDistance(mshowThreeP.getMap().getLongitude()
                                ,mshowThreeP.getMap().getLatitude(),
                                mBmobGeoPoint.getLongitude(),mBmobGeoPoint.getLatitude());
                    }


                }catch (Exception e){

                }finally {
                }

                tv_name_length.setText("距离:"+ mlenogj);
                tv_name_xj.setText("诚信程度:"+getChengxin(mshowThreeP));
                tv_name_pj.setText("官阶:"+getPj(mshowThreeP));
                
                
                llone.setVisibility(View.GONE);
                }else{
                    Toast.makeText(WorldActivity.this,"你不是会员无法查看 其信息！请充值会员",Toast.LENGTH_SHORT).show();
                 }
            }
        });
        Button  btn_closeinfo_pz=(Button)dialogView.findViewById(R.id.btn_closeinfo_pz);
        btn_closeinfo_pz.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                llone.setVisibility(View.VISIBLE);
                lltwo.setVisibility(View.GONE);
            }
        });
        TextView msg= (TextView)dialogView.findViewById(R.id.tv_mag);
         msg.setText(mshowThreeP.getMsg());
        
        Button  mdialog_cancel=(Button)dialogView.findViewById(R.id.btn_pz_no);
        mdialog_cancel.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
               mAlertDialog.dismiss();
               
            }
        });
        Button  mddialog_sure=  (Button)dialogView.findViewById(R.id.btn_pz_yes);
        mddialog_sure.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
             
               mAlertDialog.dismiss();
                BaseUtil.goPzMsgActivity(WorldActivity.this,ChatActivity.class,
                        mshowThreeP.getObjectId()
                        );
            
            }
        });
  
        normalDialog.setOnDismissListener(new DialogInterface.OnDismissListener(){

            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                mImageButton.setImageBitmap(null);
                mThreeP=null;
                readButton.setEnabled(true);
            }
        });
        // 显示
    
        mAlertDialog.setCanceledOnTouchOutside(false);
        mAlertDialog.show();
    }

    private String getPj(ThreeP mshowThreeP) {
        int number=mshowThreeP.getPj();
        switch (number){
            case 1:return "一品"; 
            case 2:return "二品"; 
            case 3:return "三品"; 
            case 4:return "四品"; 
            case 5:return "五品"; 
            case 6:return "六品"; 

            case 7:return "七品"; 
            case 8:return "八品"; 
            case 9:return "九品"; 
            case 10:  return "平民"; 
            case 11:return "坏人"; 
            
        
        }
        return "未知";
    }

    private String getChengxin(ThreeP mshowThreeP) {
        int number=mshowThreeP.getNumber();
        if(number>54){
            return "高诚信";
        }else if(number<27){
            return "低诚信危险";
        }
        return "正常";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_world);
        mImageButton=(ImageButton)findViewById(R.id.back_btn);
        writeButton=(Button)findViewById(R.id.btn_write);
        readButton= (Button)findViewById(R.id.btn_read);
        historyButton=(Button)findViewById(R.id.btn_history);
        mImageButton.setOnClickListener(this);
        writeButton.setOnClickListener(this);
        readButton.setOnClickListener(this);
        historyButton.setOnClickListener(this);
        BmobIMApplication.mHandler=worldHandler;
    }
    
    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.back_btn:
                if(mThreeP!=null){
                   
             
                    showCustomizeDialog(mThreeP);
                    mImageButton.setImageBitmap(null);
                    mThreeP=null;
                    readButton.setEnabled(true);
                }else{
                    if(rtd.isConnected()){
                        MyUser user=    getCurrentUser(MyUser.class);
                        if(user!=null){
                            rtd.unsubTableUpdate(tableNameTwoP );
                        }

                    }
                    mImageButton.setImageBitmap(null);
                    mThreeP=null;
                    readButton.setEnabled(true);

                }               
                break;
            case  btn_write:
               // Toast.makeText(WorldActivity.this,"btn_write",Toast.LENGTH_LONG).show();
                if(rtd.isConnected()){
                    MyUser user=    getCurrentUser(MyUser.class);
                    if(user!=null){
                        rtd.unsubTableUpdate(tableNameTwoP );
                    }

                }
                mImageButton.setImageBitmap(null);
                mThreeP=null;
                readButton.setEnabled(true);
                
                writeButton.setEnabled(false);
                BaseUtil.sendhandlermessage(worldHandler,false,0,"");
                break;
            case R.id.btn_read:
                readButton.setEnabled(false);
                BaseUtil.sendhandlermessage(worldHandler,false,1,"");
                //Toast.makeText(WorldActivity.this,"btn_read",Toast.LENGTH_LONG).show();
                break;
            case R.id.btn_history:
//                Toast.makeText(WorldActivity.this,"btn_history",Toast.LENGTH_LONG).show();
                BaseUtil.goActivity(WorldActivity.this,HistoryActivity.class);
              
                break;
          

        }
    }
   
    private void showCustomizeDialog() {
        final AlertDialog.Builder customizeDialog =
                new AlertDialog.Builder(WorldActivity.this);
        final View dialogView = LayoutInflater.from(WorldActivity.this)
                .inflate(R.layout.write_dialog_layout,null);
       // customizeDialog.setTitle("碰碰瓶");
       
        customizeDialog.setView(dialogView);
        final AlertDialog mAlertDialog= customizeDialog.create();
       Button  mdialog_cancel=(Button)dialogView.findViewById(R.id.dialog_cancel);
        mdialog_cancel.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                mAlertDialog.dismiss();
                writeButton.setEnabled(true);
            }
        });
        Button  mddialog_sure=  (Button)dialogView.findViewById(R.id.dialog_sure);
        mddialog_sure.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                // 获取EditView中的输入内容
                EditText edit_text =
                        (EditText) dialogView.findViewById(R.id.edt_write_text);
//                Toast.makeText(WorldActivity.this,
//                        edit_text.getText().toString(),
//                        Toast.LENGTH_SHORT).show();
                String str=edit_text.getText().toString();
                if(str!=null&&!str.trim().equals("")&&str.trim().length()>2){
                    MyUser user= getCurrentUser(MyUser.class);
                    if(user!=null){
                        
                        writeIntentService.startActionFoo(WorldActivity.this,  str.trim(),null);
                    }else{
                        
                    }
                    
                }else {
                    Toast.makeText(WorldActivity.this,
                           "信息不能为空且 大于2个字符",
                            Toast.LENGTH_SHORT).show();
                }
                mAlertDialog.dismiss();
                writeButton.setEnabled(true);
            }
        });
//        customizeDialog.setPositiveButton("确定",
//                new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        // 获取EditView中的输入内容
//                        EditText edit_text =
//                                (EditText) dialogView.findViewById(R.id.edt_write_text);
//                        Toast.makeText(WorldActivity.this,
//                                edit_text.getText().toString(),
//                                Toast.LENGTH_SHORT).show();
//                        customizeDialog.create().dismiss();
//                        writeButton.setEnabled(true);
//                    }
//                });
//        customizeDialog.setNegativeButton("取消",new DialogInterface.OnClickListener() {
//
//            @Override
//            public void onClick(DialogInterface dialogInterface, int i) {
//                customizeDialog.create().dismiss();
//                writeButton.setEnabled(true);
//            }
//        });
        mAlertDialog.setCanceledOnTouchOutside(false);
        mAlertDialog.show();
    
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(rtd.isConnected()){
            MyUser user=    getCurrentUser(MyUser.class);
            if(user!=null){
                rtd.unsubTableUpdate(tableNameTwoP );
            }

        }
        mImageButton.setImageBitmap(null);
        readButton.setEnabled(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        // 程序终止的时候执行
//        MyUser bmobUser = BmobUser.getCurrentUser(MyUser.class);
//        SharedPreferences sp=getApplicationContext().getSharedPreferences("SP",MODE_PRIVATE);
//        SharedPreferences.Editor editor=sp.edit();
//        boolean LoginLineFlag= sp.getBoolean("LoginLineFlag",false);
//        if(LoginLineFlag && bmobUser!=null){
//            editor.putBoolean("LoginLineFlag",false).commit();
//
//            MyUser newUser = new MyUser();
//            newUser.setIsline(false);
//
//            newUser.update(bmobUser.getObjectId(),new UpdateListener() {
//                @Override
//                public void done(BmobException e) {
//                    //Toast.makeText(WorldActivity.this,"WorldActivity error:"+BaseUtil.ErrorInfoString(e.getErrorCode()),Toast.LENGTH_SHORT).show();
//                }
//            });
//        }
    }

    
}
