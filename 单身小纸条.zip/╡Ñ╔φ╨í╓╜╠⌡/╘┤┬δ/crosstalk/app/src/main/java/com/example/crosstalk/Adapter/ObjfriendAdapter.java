package com.example.crosstalk.Adapter;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.crosstalk.ChatActivity;
import com.example.crosstalk.NetEnty.MyUser;
import com.example.crosstalk.R;
import com.example.crosstalk.TradeActivity;
import com.example.crosstalk.util.BaseUtil;
import com.example.crosstalk.util.ViewHolder;
import com.example.crosstalk.util.ViewMyUtil;

import java.util.List;
import java.util.Map;

import cn.bmob.v3.BmobUser;

/**
 * Created by Administrator on 2017/9/12 0012.
 */

public class ObjfriendAdapter extends SimpleAdapter {
    LayoutInflater mLayoutInflater;
    Context context;
    List<? extends Map<String, ?>> mdata;
    String[] mfrom=null;
    int[] mto=null;
    public ObjfriendAdapter(LayoutInflater mLayoutInflater,Context  context, List<? extends Map<String, ?>> data, int resource, String[] from, int[] to) {
        super(context, data, resource, from, to);
        this.context=context;
        this.mLayoutInflater=mLayoutInflater;
        this.mdata=data;
        mfrom=from;
        mto=to;
        
    }
    ProgressDialog progressDialog=null;
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      
        ViewHolder  mViewHolder = ViewHolder.get(context, convertView, R.layout.obj_item);
        TextView TextView_name=(TextView) mViewHolder.findViewById(R.id.obj_item_username);
        TextView  TextView_unreadnumber=(TextView) mViewHolder.findViewById(R.id.obj_item_unreadnumber);
        Button  TextView_recentmsg=(Button) mViewHolder.findViewById(R.id.obj_item_recentmsg);
          Button btn_lxfs=(Button) mViewHolder.findViewById(R.id.btn_lxfs);
        if (mdata.size() != 0) {
            final Map<String, String> mss = (Map<String, String>) mdata
                    .get(position);
            TextView_name.setText(mss.get(mfrom[0]));
            TextView_recentmsg.setText(mss.get(mfrom[1]));
            TextView_recentmsg.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
//                    TextView objtvname=(TextView)view.findViewById(R.id.obj_item_unreadnumber);
//                    //Toast.makeText(HistoryActivity.this,"objname:"+objtvname.getText(),Toast.LENGTH_LONG).show();
                    BaseUtil.gohisChatActivity(context,ChatActivity.class, mss.get(mfrom[2])+"");
                    ( (Activity)context).finish();
                }
            });

            final MyUser myUser= BmobUser.getCurrentUser(MyUser.class);
            TextView_unreadnumber.setText(mss.get(mfrom[2]));
            
            btn_lxfs.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(myUser.getPower()!=1){
                          progressDialog= ViewMyUtil.get_progressDialog_set(
                                context,
                                R.mipmap.ic_launcher,
                                "联系电话（未验证）：",
                                 mss.get(mfrom[2]),
                                false);
                    }else{
                        Toast.makeText(context,"你不是会员无法查看 其信息！请充值会员",Toast.LENGTH_SHORT).show();
                        BaseUtil.goActivity(context, TradeActivity.class);
                    }
                }
            });
        }
        if(mViewHolder==null){
            return convertView;
        }else{
            return mViewHolder.getConvertView();
        }
//        convertView = mLayoutInflater.inflate(R.layout.obj_item, null);
//       TextView  TextView_name=(TextView) convertView.findViewById(R.id.obj_item_username);
//        TextView  TextView_unreadnumber=(TextView) convertView.findViewById(R.id.obj_item_unreadnumber);
//        TextView  TextView_recentmsg=(TextView) convertView.findViewById(R.id.obj_item_recentmsg);
//        if (mdata.size() != 0) {
//            final Map<String, String> mss = (Map<String, String>) mdata
//                    .get(position);
//            TextView_name.setText(mss.get(mfrom[0]));
//            TextView_recentmsg.setText(mss.get(mfrom[1]));
//        }
//        return convertView;
    }
}
