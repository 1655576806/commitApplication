package com.example.crosstalk.service;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.example.crosstalk.BmobIMApplication;
import com.example.crosstalk.DAO.MSqliteUtil;
import com.example.crosstalk.LocalEnty.ChatHistory;
import com.example.crosstalk.LocalEnty.ChatObj;
import com.example.crosstalk.util.TimeUtil;
import com.example.crosstalk.util.ViewMyUtil;

/**
 * An {@link IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p>
 * TODO: Customize class - update intent actions, extra parameters and static
 * helper methods.
 */
public class receiveIntentService extends IntentService {
    // TODO: Rename actions, choose action names that describe tasks that this
    // IntentService can perform, e.g. ACTION_FETCH_NEW_ITEMS
    private static final String ACTION_FOO = "com.example.crosstalk.service.action.FOO";
    private static final String ACTION_BAZ = "com.example.crosstalk.service.action.BAZ";

    // TODO: Rename parameters
    private static final String EXTRA_PARAM1 = "com.example.crosstalk.service.extra.PARAM1";
    private static final String EXTRA_PARAM2 = "com.example.crosstalk.service.extra.PARAM2";
    private static final String EXTRA_PARAM3 = "com.example.crosstalk.service.extra.PARAM3";
    private static final String EXTRA_PARAM4 = "com.example.crosstalk.service.extra.PARAM4";
    private static final String EXTRA_PARAM5 = "com.example.crosstalk.service.extra.PARAM5";
    public receiveIntentService() {
        super("receiveIntentService");
    }

    /**
     * Starts this service to perform action Foo with the given parameters. If
     * the service is already performing a task this action will be queued.
     *
     * @see IntentService
     */
    // TODO: Customize helper method
    public static void startActionFoo(Context context, String param1, String param2) {
        Intent intent = new Intent(context, receiveIntentService.class);
        intent.setAction(ACTION_FOO);
        intent.putExtra(EXTRA_PARAM1, param1);
        intent.putExtra(EXTRA_PARAM2, param2);
        context.startService(intent);
    }
    static Context  mContext;
    /**
     * Starts this service to perform action Baz with the given parameters. If
     * the service is already performing a task this action will be queued.
     *
     * @see IntentService
     */
    // TODO: Customize helper method
    public static void startActionBaz(Context context,String param1,String param2
            ,String param3
            ,String param4,String param5) {
        mContext=context;
        Intent intent = new Intent(context, receiveIntentService.class);
        intent.setAction(ACTION_BAZ);
        intent.putExtra(EXTRA_PARAM1, param1);
        intent.putExtra(EXTRA_PARAM2, param2);
        intent.putExtra(EXTRA_PARAM3, param3);
        intent.putExtra(EXTRA_PARAM4, param4);
        intent.putExtra(EXTRA_PARAM5, param5);
        context.startService(intent);
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            final String action = intent.getAction();
            if (ACTION_FOO.equals(action)) {
                final String param1 = intent.getStringExtra(EXTRA_PARAM1);
                final String param2 = intent.getStringExtra(EXTRA_PARAM2);
                handleActionFoo(param1, param2);
            } else if (ACTION_BAZ.equals(action)) {
                final String param1 = intent.getStringExtra(EXTRA_PARAM1);
                final String param2 = intent.getStringExtra(EXTRA_PARAM2);
                final String param3 = intent.getStringExtra(EXTRA_PARAM3);
                final String param4 = intent.getStringExtra(EXTRA_PARAM4);
                final String param5 = intent.getStringExtra(EXTRA_PARAM5);
                handleActionBaz(param1, param2,param3,param4,param5);
            }
        }
    }

    /**
     * Handle action Foo in the provided background thread with the provided
     * parameters.
     */
    private void handleActionFoo(String param1, String param2) {
         
    }

    /**
     * Handle action Baz in the provided background thread with the provided
     * parameters.
     */
    private void handleActionBaz(String username, String sendtime, String infomsg, String obj_InstallationId
    ,String ObjNick) {
        //查询对象数据是否存在该 收到的对象
        //存在 将 聊天数据存储到聊天历史表中
        //不存在
            //创建在聊天对象中该对象
               //成功后  将 聊天数据存储到聊天历史表中
               //失败
         
        ChatHistory mChatHistory=new ChatHistory();
        mChatHistory .setObjnames(username);
        
        mChatHistory.setNick(ObjNick);
        
        mChatHistory.setMsginfo(infomsg);
        mChatHistory.setInstallationId(obj_InstallationId);
        mChatHistory.setTime(TimeUtil.getTimemili());
        
        mChatHistory.setIsread(1);
        mChatHistory.setType(1);//obj
      
        int count= MSqliteUtil.queryChatObj(mChatHistory.getObjnames() ,null);
       // Toast.makeText(ChatActivity.this,"world_to_ChatObj_count:"+count,Toast.LENGTH_LONG).show();
        //判断 历史回话是否存在过这个对象
        if(count>0){
            //存在  
            //将这条消息 插入聊天历史数据库
            Go_Broadcast_UpdateView(mChatHistory);
//            BmobIMApplication.getReadlockCustom().writeLock().lock();
//            try {
//                mChatHistory.saveThrows();
//            } catch (Exception ex) {
//                ViewMyUtil.shwoNotifi(mContext, "本地异常！本地存储聊天对话失败"
//                        , null, null, null);
//              
//            }finally{
//                BmobIMApplication.getReadlockCustom().writeLock().unlock();
//            }
//            String toObjName=objectTwoP.getUsername();
//            //成功  //显示在界面上
//            BaseUtil.sendhandlermessage(mChatHandler,false,2,toObjName);
        }else if(count==0){
            //  不存在
            // 创建该回合 插入对象数据表
            ChatObj newChatObj=new ChatObj();
            newChatObj.setIsread(1);
            newChatObj.setObjname(mChatHistory.getObjnames());
            
            newChatObj.setNick(ObjNick);
            
            newChatObj.setTimemil(mChatHistory.getTime());
            BmobIMApplication.getReadlockCustom().writeLock().lock();
            try {
                newChatObj.saveThrows();
            } catch (Exception ex) {
                ViewMyUtil.shwoNotifi(mContext, "本地异常！本地存储聊天对像失败"
                        , null, null, null);
           }finally{
                BmobIMApplication.getReadlockCustom().writeLock().unlock();
            }

            Go_Broadcast_UpdateView(mChatHistory);
          
//            String toObjName=objectTwoP.getUsername();
//            //成功  //显示在界面上
//            BaseUtil.sendhandlermessage(mChatHandler,false,2,toObjName);
        }else{
            //异常
            ViewMyUtil.shwoNotifi(mContext, "本地聊天对象查询异常！"
                    , null, null, null);
        }
  

    }

    private void Go_Broadcast_UpdateView(ChatHistory mChatHistory) {
        BmobIMApplication.getReadlockCustom().writeLock().lock();
        try {
            mChatHistory.saveThrows();
        } catch (Exception ex) {
            ViewMyUtil.shwoNotifi(mContext, "本地异常！本地存储聊天对话失败"
                    , null, null, null);

        }finally{
            BmobIMApplication.getReadlockCustom().writeLock().unlock();
        }
        //通知更新 chat界面 his对象界面
        //在主线程发送广播
        Intent intent = new Intent( BmobIMApplication.updateViewAction) ;
//        intent.putExtra( "data" , "主线程发过来的消息" ) ;
        Bundle bd=new Bundle();
        
        bd.putString("username",mChatHistory.getObjnames());
        bd.putString("infomsg",mChatHistory.getMsginfo());
        bd.putString("obj_InstallationId",mChatHistory.getInstallationId());
        bd.putLong("Time",mChatHistory.getTime());
        bd.putInt("Isread",mChatHistory.isread());
        bd.putInt("Type",mChatHistory.getType());
        
        bd.putString("nick",mChatHistory.getNick());
        
        intent.putExtras(bd);
        BmobIMApplication.localBroadcastManager.sendBroadcast( intent ) ;


    }

}
