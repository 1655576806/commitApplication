package com.example.crosstalk.Enty;

/**
 * 交易市场表
 * Created by Administrator on 2017/9/10 0010.
 */

public class TradeMarket {
    private String username;//用户账号key
    private String tradenumber;//商品编号
    private int price;//自定义价格
    private  int  number;//自定义数量
    private  String time;//发布时间
}
