package com.example.crosstalk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.example.crosstalk.service.receiveIntentService;
import com.example.crosstalk.util.ViewMyUtil;

import org.json.JSONException;
import org.json.JSONObject;

import cn.bmob.push.PushConstants;
import cn.bmob.v3.BmobInstallationManager;


/**
 * Created by Administrator on 2017/9/8 0008.
 */

//TODO 集成：1.3、创建自定义的推送消息接收器，并在清单文件中注册
public class MyPushMessageReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO Auto-generated method stub
        if(intent.getAction().equals(PushConstants.ACTION_MESSAGE)) {
            //Log.d("bmob", "客户端收到推送内容："+intent.getStringExtra("msg"));
            String msg = intent.getStringExtra("msg");

            JSONObject newJSONObject = null;
            String alertJson = null;
            String InstallationId = null;
            String infomsg = null;
            String time = null;
            String username = null;
            String mNick=null;
            try {
                newJSONObject = new JSONObject(msg);
                alertJson = newJSONObject.optString("alert");
           
            JSONObject newalertJson=null;
            try {
                newalertJson = new JSONObject(alertJson);
                //非字符串
                try {
                    InstallationId = newalertJson.getString("InstallationId");
                    infomsg = newalertJson.getString("msg");
                    time = newalertJson.getString("time");
                    username = newalertJson.getString("username");
                        mNick = newalertJson.getString("nick");
                    
                    if( BmobInstallationManager.getInstallationId().equalsIgnoreCase(InstallationId)){
//                        ViewMyUtil.shwoNotifi(context, "自己发送成功的回折"
//                                , null, null, null);
                    }else{
                        //接受到一一份信件
                         // 开启接受服务线程
                        receiveIntentService.startActionBaz(context,username,time,infomsg,InstallationId
                                ,mNick);
//                        ViewMyUtil.shwoNotifi(context, username + "\t" +
//                                        time + "\t" +
//                                        infomsg + "\t" +
//                                        InstallationId + "\t"
//                                , null, null, null);
                    }
                  
                } catch (JSONException e) {
                    ViewMyUtil.shwoNotifi(context, "getString"
                            , null, null, null);
                }
              } catch (JSONException e) {
                //字符串
                ViewMyUtil.shwoNotifi(context, alertJson
                        , null, null, null);
               
              }

            } catch (JSONException e) {
                ViewMyUtil.shwoNotifi(context, "optString alert"
                        , null, null, null);

            }

        }}
     
}
