package com.example.crosstalk.util;

import android.content.Context;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by Administrator on 2017/9/13 0013.
 */

public class ViewHolder {
    private final SparseArray<View> sparseVies;
    private View convertView;
   private int mitemResourceId;
    private ViewHolder(Context context, int itemResourceId) {
        sparseVies = new SparseArray<View>();
        convertView = LayoutInflater.from(context).inflate(itemResourceId, null);
        convertView.setTag(this);
        mitemResourceId=itemResourceId;
    }

    private ViewHolder(Context context, int itemResourceId,ViewGroup viewGroup) {
        sparseVies = new SparseArray<View>();
        convertView = LayoutInflater.from(context).inflate(itemResourceId, viewGroup);
        convertView.setTag(this);
    }


    public static ViewHolder get(Context context, View convertView, int itemResourceId) {
        if (convertView == null) {
          
            return new ViewHolder(context, itemResourceId);
        }
        ViewHolder mViewHolder= (ViewHolder) convertView.getTag();
        if(mViewHolder.mitemResourceId!=itemResourceId){
            return new ViewHolder(context, itemResourceId);
        }
        return (ViewHolder) convertView.getTag();
    }

    public static ViewHolder get(Context context, View convertView, int itemResourceId,ViewGroup  vierGroup) {
        if (convertView == null) {
          
            return new ViewHolder(context, itemResourceId,vierGroup);
        }
      
        return (ViewHolder) convertView.getTag();
    }


    public <T extends View> T getView(int viewId) {
        View view = sparseVies.get(viewId);
        if (view == null) {
            view = convertView.findViewById(viewId);
            sparseVies.put(viewId, view);
        }
        return (T) view;
    }

    public <T extends View> T findViewById(int viewId) {
        return getView(viewId);
    }

    public View getConvertView() {
        return convertView;
    }
}
