package com.example.crosstalk.NetEnty;

import cn.bmob.v3.datatype.BmobGeoPoint;

/**
 * Created by Administrator on 2017/9/11 0011.
 */

public class ManPzi  {
    private String username;//用户账号key
    private String pj;//品级
    private String number;//诚信指数1-81 男41  女40
    
    private BmobGeoPoint  map;//地点
    private String time;//时间
    private String msg;//消息
    private int   objps;//目标对象 1-10
    private boolean readed;//是否已读

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPj() {
        return pj;
    }

    public void setPj(String pj) {
        this.pj = pj;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public BmobGeoPoint getMap() {
        return map;
    }

    public void setMap(BmobGeoPoint map) {
        this.map = map;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getObjps() {
        return objps;
    }

    public void setObjps(int objps) {
        this.objps = objps;
    }

    public boolean isReaded() {
        return readed;
    }

    public void setReaded(boolean readed) {
        this.readed = readed;
    }
}
