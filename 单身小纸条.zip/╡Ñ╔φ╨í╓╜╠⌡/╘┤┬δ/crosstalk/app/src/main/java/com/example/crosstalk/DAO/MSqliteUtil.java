package com.example.crosstalk.DAO;

import android.app.ProgressDialog;

import com.example.crosstalk.BmobIMApplication;
import com.example.crosstalk.LocalEnty.ChatHistory;
import com.example.crosstalk.LocalEnty.ChatObj;

import org.litepal.crud.DataSupport;

import java.util.ArrayList;

/**
 * Created by Administrator on 2017/9/11 0011.
 */

public class MSqliteUtil {
     
    /**
     * 查询 聊天对象是否存在
     */
    public  static int  queryChatObj(String  objname ,ProgressDialog progressDialog){
        int count=-1;
        BmobIMApplication.getReadlockCustom().readLock().lock();
        try {
            count =  DataSupport.where("objname=? ",objname).count(ChatObj.class);
        }catch (Exception e){
            if(progressDialog!=null){
                progressDialog.setTitle("异常");
                progressDialog.setMessage("查询历史数据表失败.");
            }
     
        }finally {
            BmobIMApplication.getReadlockCustom().readLock().unlock();// 释放读锁  
        }
        return count;
    }
 
    public  static ArrayList<ChatHistory> queryChat_ObjChatHistory( String  objname,ProgressDialog progressDialog,int Show_ObjChatHistory_Count){
        ArrayList<ChatHistory> jtes=null;
        BmobIMApplication.getReadlockCustom().readLock().lock();
        try {
            jtes = (ArrayList<ChatHistory>) DataSupport.where("objnames=? ",objname).order("time desc").limit(Show_ObjChatHistory_Count).find(ChatHistory.class);
        }catch (Exception e){
            progressDialog.setTitle("异常");
            progressDialog.setMessage("查询历史数据表失败.");
          
        }finally {
            BmobIMApplication.getReadlockCustom().readLock().unlock();// 释放读锁  
        }
        return jtes;
    }
  public  static ArrayList<ChatObj>  queryhisObj(ProgressDialog progressDialog,int ShowChatObjCount){
      ArrayList<ChatObj> jtes=null;
      BmobIMApplication.getReadlockCustom().readLock().lock();
      try {
          jtes = (ArrayList<ChatObj>) DataSupport.where("isread=?", 1+"")
                  .order("timemil desc").limit(ShowChatObjCount).find(ChatObj.class);
      }catch (Exception e){
          progressDialog.setTitle("异常");
          progressDialog.setMessage("查询好友数据表失败.");
          
      }finally {
          BmobIMApplication.getReadlockCustom().readLock().unlock();// 释放读锁  
      }
      return  jtes;
  }
    public  static ChatHistory queryhisChatHistory(String name ,ProgressDialog progressDialog){
        ArrayList<ChatHistory> lastNews=null;
 
        BmobIMApplication.getReadlockCustom().readLock().lock();
        try {
            lastNews = (ArrayList<ChatHistory>) DataSupport.where("objnames=? and type=?",name,1+"").order("time desc").limit(1).find(ChatHistory.class);
        }catch (Exception e){
            progressDialog.setTitle("异常");
            progressDialog.setMessage("查询历史数据表失败.");
            
        }finally {
            BmobIMApplication.getReadlockCustom().readLock().unlock();// 释放读锁  
        }
        
        if(lastNews!=null&&lastNews.size()==1){
            return  lastNews.get(0);
        }else
        {
            return  null;
        }
    
    }

  
}
