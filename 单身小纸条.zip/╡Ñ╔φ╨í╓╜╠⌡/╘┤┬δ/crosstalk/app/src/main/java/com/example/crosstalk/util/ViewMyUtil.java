package com.example.crosstalk.util;

import android.app.Notification;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.NotificationCompat;

import com.example.crosstalk.R;

import org.json.JSONObject;

/**
 * Created by Administrator on 2017/9/11 0011.
 */

public class ViewMyUtil {
/**
 * progressdialog
 */
public static ProgressDialog get_progressDialog_set(Context mContext, int Micon,
                                                    String mTitle, String mMessage,
                                                    Boolean isCanceledOnTouchOutside 
                                                    ) {
    ProgressDialog   mProgressDialog
            = new ProgressDialog(mContext);
    mProgressDialog.setIcon(Micon);
    mProgressDialog.setTitle(mTitle);
    mProgressDialog.setMessage(mMessage);
    mProgressDialog.setCanceledOnTouchOutside(isCanceledOnTouchOutside);
    mProgressDialog.show();
    return mProgressDialog;
}
    /**
     *  Notification
     */
    static NotificationManagerCompat managerCompat ;
    
    private static Notification initNotfication(Context context, String str
            , String Ticker, String ContentTitle, String ContentText){
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context);
        //设置小图标
        builder.setSmallIcon(R.mipmap.ic_launcher);
        //设置大图标
        builder.setLargeIcon(BitmapFactory.decodeResource(context.getResources(),R.mipmap.ic_launcher));
        if(Ticker==null){
            builder.setTicker("Ticker");
        }else{
            builder.setTicker(Ticker);
        }
        //设置标题
        if(Ticker==null){
            builder.setContentTitle("ContentTitle");
        }else{
            builder.setContentTitle(ContentTitle);
        }
        //设置标题下面的内容
        if(Ticker==null){
            builder.setContentText("ContentText");
        }else{
            builder.setContentText(ContentText);
        }
       
        //设置右侧时间下面的内容
        builder.setContentInfo(str);
        //设置时间
        builder.setWhen(System.currentTimeMillis());
        return builder.build();
    }
    public static void shwoNotifi(Context context, String str
            , String Ticker, String ContentTitle, String ContentText){
        managerCompat = NotificationManagerCompat.from(context);
        if (managerCompat !=null){
            managerCompat.notify(0, initNotfication( context,str  ,   Ticker,  
                    ContentTitle,   ContentText));
        }
    }
    public static void shwoNotifi(Context context, JSONObject mJSONObject
            , String Ticker, String ContentTitle, String ContentText)  {
            String get_InstallationId= mJSONObject.optString("InstallationId");
            String get_username= mJSONObject.optString("username");
            String get_time=mJSONObject.optString("time");
            String get_msg=mJSONObject.optString("msg");
            managerCompat = NotificationManagerCompat.from(context);
            if (managerCompat !=null){
                managerCompat.notify(0, initNotfication( context, "get_InstallationId:"+get_InstallationId+"\t"+
                                "get_username:"+get_username+"\t"+ "get_time:"+get_time+"\t"+
                                "get_msg:"+get_msg+"\t" ,   Ticker,
                        ContentTitle,   ContentText));
            }
       
    }
}
