package com.example.crosstalk.Enty;

/**
 * 游戏道具表
 * Created by Administrator on 2017/9/10 0010.
 */

public class GameTradeKind {
    private int id;//道具id
    private String GameTradename;//服务道具名
    private String GameTradeinfo;//服务道具描述
    private String price;//服务道具价格
    private int time;//有效时间
}
