package com.example.crosstalk;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.crosstalk.Adapter.ObjfriendAdapter;
import com.example.crosstalk.DAO.MSqliteUtil;
import com.example.crosstalk.LocalEnty.ChatHistory;
import com.example.crosstalk.LocalEnty.ChatObj;
import com.example.crosstalk.util.Base;
import com.example.crosstalk.util.BaseUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HistoryActivity extends Base {
    int ShowChatObjCount=5;
    ListView objll;
    ObjfriendAdapter mObjfriendAdapter;
    LayoutInflater mLayoutInflater;
    String[] from={"username","recentmsg","zhuanghuo"};
    int[]  to={R.id.obj_item_username,R.id.obj_item_recentmsg};

    ProgressDialog progressDialog;
    ArrayList<ChatObj> jtes=null;
    Handler hisHandler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            Bundle bd = msg.getData();
            switch (bd.getInt("key")) {
                case 0:
                    
                    progressDialog
                            = new ProgressDialog(HistoryActivity.this);
                    progressDialog.setIcon(R.mipmap.ic_launcher);
                    progressDialog.setTitle("等待");
                    progressDialog.setMessage("正在加载....");
                    progressDialog.show();
                    progressDialog.setCanceledOnTouchOutside(false);
                   jtes= MSqliteUtil.queryhisObj(progressDialog,ShowChatObjCount);
//                    ArrayList<ChatObj> jtes=null;
//                    BmobIMApplication.getReadlockCustom().readLock().lock();
//                   try {
//                       jtes = (ArrayList<ChatObj>) DataSupport.where("isread=?", 1+"")
//                               .order("timemil desc").limit(5).find(ChatObj.class);
//                   }catch (Exception e){
//                       progressDialog.setTitle("异常");
//                       progressDialog.setMessage("查询好友数据表失败.");
//                   }finally {
//                       BmobIMApplication.getReadlockCustom().readLock().unlock();// 释放读锁  
//                   }

                    if(jtes!=null && jtes.size()>=1){
                        progressDialog.setMessage(" 正加载...."+jtes.size()+"条记录");
                    }else{
                        progressDialog.setMessage(" 无记录....");
                        return;
                    }
                    mObjfriendAdapter=new ObjfriendAdapter(mLayoutInflater,HistoryActivity.this,getData(jtes,progressDialog),R.layout.obj_item,from,to);
                    objll.setAdapter(mObjfriendAdapter);
                    BmobIMApplication.serviceThreadPool.submit(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                ((ObjfriendAdapter) objll.getAdapter())
                                        .notifyDataSetChanged();
                            } catch (Exception e) {
                            }
                        }
                    });
                    progressDialog.dismiss();
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        objll=(ListView)findViewById(R.id.obj_lst);
        mLayoutInflater=  this.getLayoutInflater();
        objll.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView objtvname=(TextView)view.findViewById(R.id.obj_item_unreadnumber);
                //Toast.makeText(HistoryActivity.this,"objname:"+objtvname.getText(),Toast.LENGTH_LONG).show();
                BaseUtil.gohisChatActivity(HistoryActivity.this,ChatActivity.class,objtvname.getText()+"");
               finish();
            }
        });
    }
    HisBroadcastReceiver mhisBroadcastReceiver=null;
    IntentFilter mintentFilter=null;
    @Override
    protected void onResume() {
        super.onResume();
        //注册广播接收器

        mhisBroadcastReceiver = new HisBroadcastReceiver() ;
        mintentFilter = new IntentFilter(BmobIMApplication.updateViewAction) ;
        if(BmobIMApplication.localBroadcastManager!=null&& mhisBroadcastReceiver!=null&& mintentFilter!=null){
            BmobIMApplication.localBroadcastManager.registerReceiver( mhisBroadcastReceiver , mintentFilter );
        }

        if(mlist!=null)
        {
            mlist.clear();
        }
           
        BaseUtil.sendhandlermessage(hisHandler,false,0,"");
      
    }
    private class HisBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction() ;
            if ( BmobIMApplication.updateViewAction.equals( action )){
                // 更新ui
                //显示在界面上
                if(mlist!=null)
                {
                    mlist.clear();
                }

                BaseUtil.sendhandlermessage(hisHandler,false,0,"");
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        //取消注册广播,防止内存泄漏
        if(BmobIMApplication.localBroadcastManager!=null&&mhisBroadcastReceiver!=null){
            BmobIMApplication.localBroadcastManager.unregisterReceiver( mhisBroadcastReceiver );
        }
    }

    ArrayList<Map<String, String>> mlist = new ArrayList<Map<String, String>>();
    private List<? extends Map<String,?>> getData(ArrayList<ChatObj> jtes,ProgressDialog progressDialog) {
        int count = jtes.size();
        for (int i = 0; i < count; i++) {
            HashMap<String, String> hs = new HashMap<String, String>();
            ChatObj hbd = jtes.get(i);
        
            hs.put(from[0],  hbd.getNick());
            ChatHistory lastNews= MSqliteUtil.queryhisChatHistory(hbd.getObjname(),progressDialog);
//            ChatHistory lastNews = DataSupport.where("objnames=? and type=?",hbd.getObjname(),1+"").findLast(ChatHistory.class);
            hs.put(from[1], lastNews.getMsginfo());
          
           hs.put(from[2], hbd.getObjname());
            mlist.add(hs);
        }
        return mlist;
    }
     



   
}
