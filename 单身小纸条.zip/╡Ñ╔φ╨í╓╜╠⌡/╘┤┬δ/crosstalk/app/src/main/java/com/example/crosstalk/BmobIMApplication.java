package com.example.crosstalk;

import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Handler;
import android.support.v4.content.LocalBroadcastManager;

import com.example.crosstalk.NetEnty.MyUser;
import com.pgyersdk.crash.PgyCrashManager;

import org.litepal.LitePal;
import org.litepal.LitePalApplication;
import org.litepal.tablemanager.Connector;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.UpdateListener;


/**
 * Created by Administrator on 2017/8/5 0005.
 */

public class BmobIMApplication extends LitePalApplication {
    public static   String updateViewAction="obj_chat_his_update";
    public static  LocalBroadcastManager localBroadcastManager = null ;
    public static ExecutorService serviceThreadPool = Executors.newFixedThreadPool (5);
   //public  static  boolean  LoginLineFlag=false; //是否是当前应用修改在线状态 的标志
   private static ReadWriteLock rwl ;

    public     static  ReadWriteLock getReadlockCustom()
    {
        if(rwl==null){
            rwl= new ReentrantReadWriteLock();
        }
        return rwl;
    };
  public static Handler mHandler;
    @Override
    public void onCreate() {
        super.onCreate();
        localBroadcastManager = LocalBroadcastManager.getInstance( getApplicationContext() ) ;
        SQLiteDatabase db = Connector.getDatabase();
        LitePal.initialize(getApplicationContext());
        PgyCrashManager.register(getApplicationContext());
        //TODO 集成：1.4、初始化数据服务SDK、初始化设备信息并启动推送服务

    }
    @Override
    public void onTerminate() {
        // 程序终止的时候执行
       
        MyUser bmobUser = BmobUser.getCurrentUser(MyUser.class);
        SharedPreferences sp=getApplicationContext().getSharedPreferences("SP",MODE_PRIVATE);
        SharedPreferences.Editor editor=sp.edit();
        boolean LoginLineFlag= sp.getBoolean("LoginLineFlag",false);
        if(LoginLineFlag && bmobUser!=null){
            editor.putBoolean("LoginLineFlag",false).commit();

            MyUser newUser = new MyUser();
            newUser.setIsline(false);

            newUser.update(bmobUser.getObjectId(),new UpdateListener() {
                @Override
                public void done(BmobException e) {
                    //Toast.makeText(WorldActivity.this,"WorldActivity error:"+BaseUtil.ErrorInfoString(e.getErrorCode()),Toast.LENGTH_SHORT).show();
                }
            });
        }
        super.onTerminate();
    }
    @Override
    public void onLowMemory() {
      
        super.onLowMemory();
    }
    @Override
    public void onTrimMemory(int level) {
        
        super.onTrimMemory(level);
    }
    /**
     * 获取当前运行的进程名
     * @return
     */
    public static String getMyProcessName() {
        try {
            File file = new File("/proc/" + android.os.Process.myPid() + "/" + "cmdline");
            BufferedReader mBufferedReader = new BufferedReader(new FileReader(file));
            String processName = mBufferedReader.readLine().trim();
            mBufferedReader.close();
            return processName;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
