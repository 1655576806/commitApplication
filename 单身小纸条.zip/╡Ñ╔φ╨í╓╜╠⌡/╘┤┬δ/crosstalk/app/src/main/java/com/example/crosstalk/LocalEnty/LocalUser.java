package com.example.crosstalk.LocalEnty;

import org.litepal.crud.DataSupport;

/**
 * Created by Administrator on 2017/9/9 0009.
 */

 
public class LocalUser extends DataSupport {

//    @Column(unique = true, defaultValue = "unknown")
//    private String name;
//
//    private float price;
//
//    private byte[] cover;

    //private List<Song> songs = new ArrayList<Song>();

    // generated getters and setters.
    
}