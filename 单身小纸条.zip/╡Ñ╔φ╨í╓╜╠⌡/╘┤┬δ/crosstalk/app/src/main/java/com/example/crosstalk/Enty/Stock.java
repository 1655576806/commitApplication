package com.example.crosstalk.Enty;

/**
 * 股份表
 * Created by Administrator on 2017/9/10 0010.
 */

public class Stock {
    private String username;//用户账号key
    private int sum;//消费
    private int stockbfb;//股份比
    private String tgm;//推广码
}
