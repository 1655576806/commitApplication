package com.example.crosstalk;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import com.example.crosstalk.Enty.RexResult;
import com.example.crosstalk.NetEnty.MyUser;
import com.example.crosstalk.util.BaseActivity;
import com.example.crosstalk.util.BaseUtil;

import cn.bmob.push.BmobPush;
import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobInstallation;
import cn.bmob.v3.BmobInstallationManager;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.InstallationListener;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FetchUserInfoListener;
import cn.bmob.v3.listener.LogInListener;
import cn.bmob.v3.listener.UpdateListener;

import static com.example.crosstalk.util.Base.isNogin;


public class MainActivity extends BaseActivity implements View.OnClickListener {
  private Button btn_login;

   

    private Button btn_register;
    ProgressDialog progressDialog;
    Handler maHandler=new Handler(
    ){
        @Override
        public void handleMessage(Message msg) {
            Bundle bd = msg.getData();
            switch (bd.getInt("key")) {
                 case 0:
                     progressDialog
                             = new ProgressDialog(MainActivity.this);
                     progressDialog.setIcon(R.mipmap.ic_launcher);
                     progressDialog.setTitle("等待");
                     progressDialog.setMessage("正在加载....");
                     progressDialog.show();
                     progressDialog.setCanceledOnTouchOutside(false);

                     final String  number=  edt_username_login.getText().toString();
                     final String  pass=  edt_pass_login.getText().toString();
                   

                     final RexResult regexResult=BaseUtil.regexUser( number, pass);
                     if(regexResult!=null&&!regexResult.isResult()){
                         progressDialog.setTitle("错误！");
                         String errorstring="";

                         if(regexResult.getErrorNumberString()!=null){
                             errorstring+="* "+regexResult.getErrorNumberString()+"\n";
                         }
                         if(regexResult.getErrorPassString() !=null){
                             errorstring+="* "+regexResult.getErrorPassString()+"\n";
                         }
                         
                         progressDialog.setMessage(errorstring);
                     } ;
                     BmobIMApplication.serviceThreadPool.submit(new Runnable()
                     {

                         @Override
                         public void run()
                         {
                             try {
                                 if(regexResult!=null&&!regexResult.isResult()){
                                     Thread.sleep(3000);
                                 }else{
                                     BmobUser.loginByAccount(number, pass, new LogInListener<MyUser>() {

                                         @Override
                                         public void done(MyUser user, BmobException e) {
                                             if(user!=null){
                                                 MyUser newUser=new MyUser();
                                                 if(user.isline()){
                                                     progressDialog.setMessage("刚登录过了，尝试下线。。。");
                                                     newUser.setIsline(false);
                                                     newUser.update(user.getObjectId(), new UpdateListener() {

                                                         @Override
                                                         public void done(BmobException e) {
                                                             if(e==null){
                                                                 progressDialog.setMessage(" 下线成功请再次登录");
                                                             }else{
                                                                 progressDialog.setMessage("在线状态修改失败！="+  BaseUtil.ErrorInfoString(e.getErrorCode()));
                                                             }
                                                         }

                                                     });
                                                    
                                                 }else{
                                                    
                                                     newUser.setIsline(true);
                                                     newUser.update(user.getObjectId(), new UpdateListener() {

                                                         @Override
                                                         public void done(BmobException e) {
                                                             if(e==null){
                                                                 
                                                                 SharedPreferences sp=getApplicationContext().getSharedPreferences("SP",MODE_PRIVATE);
                                                                 SharedPreferences.Editor editor=sp.edit();
                                                                 //boolean LoginLineFlag= sp.getBoolean("LoginLineFlag",false);
                                                                 editor.putBoolean("LoginLineFlag",true);
                                                                 editor.putString("pass",pass);
                                                                 editor.commit();
                                                               //  BmobIMApplication.LoginLineFlag=true;
                                                                 isNogin=true;
                                                                 progressDialog.setMessage("用户登陆成功:");
                                                                 BmobUser.fetchUserJsonInfo(new FetchUserInfoListener<String>() {
                                                                     @Override
                                                                     public void done(String s, BmobException e) {

                                                                     }
                                                                 });
                                                                 Intent it = new Intent(getBaseContext(), WorldActivity.class);
                                                                 startActivity(it);
                                                                 finish();
                                                             }else{
                                                                 isNogin=false;
                                                                 progressDialog.setMessage("在线状态修改失败！="+  BaseUtil.ErrorInfoString(e.getErrorCode()));
                                                             }
                                                         }

                                                     });
                                                 }
                                               
                                             }else{
                                                 isNogin=false;
                                                 progressDialog.setMessage("登陆失败！="+  BaseUtil.ErrorInfoString(e.getErrorCode()));

                                             }
                                         }
                                     });
                                     Thread.sleep(3000);
                                 }
                             }
                             catch (Exception
                                     e) {
                               //  e.printStackTrace();
                             }
                             finally{
                                 if (!MainActivity.this.isFinishing()) {
                                     progressDialog.dismiss();
                                     btn_login.setEnabled(true);
                                 }
                              
                             }
                         }
                     }) ;
                     break;
                case 1:  
                    Intent itt = new Intent(getBaseContext(), Register.class);
                    startActivity(itt);break;
                
                case 2:
                 
                break;
             }
        }
    };
    private TextView edt_pass_login;
    private TextView edt_username_login;
    private    Switch switch_autologin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        btn_login=(Button)findViewById(R.id.btn_login);
        btn_register=(Button)findViewById(R.id.btn_register);
        btn_login.setOnClickListener(this);
        btn_register.setOnClickListener(this);
        edt_username_login=(TextView)findViewById(R.id.edt_username_login);
        edt_pass_login=(TextView)findViewById(R.id.edt_pass_login);

          switch_autologin=(Switch)findViewById(R.id.switch_autologin);
        switch_autologin. setOnCheckedChangeListener(new Switch.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {
                SharedPreferences sp=getApplicationContext().getSharedPreferences("SP", Context.MODE_APPEND);
                SharedPreferences.Editor editor=sp.edit();
               
                if (isChecked) {
                    editor.putBoolean("autoFlag",false);
             
                } else {
                    editor.putBoolean("autoFlag",true);
 
                }
                editor.commit();
            }
        });
        // 初始化BmobSDK
         Bmob.initialize(this,mAppId,"bomb");
        // 使用推送服务时的初始化操作
        BmobInstallationManager.getInstance().initialize(new InstallationListener<BmobInstallation>() {
            @Override
            public void done(BmobInstallation bmobInstallation, BmobException e) {
                if (e == null) {
                  //  Logger.i(bmobInstallation.getObjectId() + "-" + bmobInstallation.getInstallationId());
                } else {
                   // Logger.e(e.getMessage());
                }
            }
        });
// 启动推送服务
        BmobPush.startWork(this);
//    ad    CrosstalkMan.getInstance(this,"57efa4c23d8f8d8737e03005aae65b91","official").create();
    }
    String mAppId= "fa59d66263639330ae8be361d950dbb0";
    
    @Override
    protected void onResume() {
        super.onResume();
        MyUser userInfo = BmobUser.getCurrentUser(MyUser.class);
        SharedPreferences sp=getApplicationContext().getSharedPreferences("SP", Context.MODE_APPEND);
        SharedPreferences.Editor editor=sp.edit();
        boolean LoginLineFlag= sp.getBoolean("LoginLineFlag",false);
        //editor.putBoolean("LoginLineFlag",true);
//        Toast.makeText(MainActivity.this,"LoginLineFlag:"+LoginLineFlag,Toast.LENGTH_SHORT).show();
        boolean autoFlag= sp.getBoolean("autoFlag",false);
        switch_autologin.setChecked(!autoFlag);
        if(userInfo!=null ){
            if(LoginLineFlag&&userInfo.isline()&&isNogin){
                Intent intent = new Intent(getBaseContext(),
                        WorldActivity.class);
                startActivity(intent);
                finish();
            }
            String username= userInfo.getUsername();
            edt_username_login.setText(username);
            String userpass= sp.getString("pass","");
          
            if(userpass!=null &&!userpass.trim().equals("")){
                edt_pass_login.setText(userpass);
            }
            if( autoFlag ){
                BaseUtil.sendhandlermessage(maHandler, false, 0, null);
            }
            
        }

    }
    @Override
    public void onClick(View view) {
switch (view.getId()){
    case R.id.btn_login:
        btn_login.setEnabled(false);
        BaseUtil.sendhandlermessage(maHandler, false, 0, null);
       
        break;
    case R.id.btn_register:
        
        BaseUtil.sendhandlermessage(maHandler, false, 1, null);

        
        break;
}
    }

    @Override
    protected void onPause() {
        super.onPause();
        
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
      
    }
} 
