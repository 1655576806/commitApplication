package com.example.crosstalk;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import com.example.crosstalk.Enty.RexResult;
import com.example.crosstalk.NetEnty.ChengShiNE;
import com.example.crosstalk.NetEnty.MyUser;
import com.example.crosstalk.NetEnty.UserInfo;
import com.example.crosstalk.util.Base;
import com.example.crosstalk.util.BaseActivity;
import com.example.crosstalk.util.BaseUtil;

import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FetchUserInfoListener;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.LogInListener;
import cn.bmob.v3.listener.SaveListener;
import cn.bmob.v3.listener.UpdateListener;


public class Register extends BaseActivity implements View.OnClickListener {
private  EditText edt_phonenumber;
    private  EditText edt_password;
    private  EditText edt_nick;
    private  EditText edt_youjian;
    private Switch switch_sex;
    private SeekBar seekBar_age;
    private TextView tv_age;
    private TextView tv_sex;
    Button  btn_register_reg;
    private TextView tv_number_reg;
    private TextView tv_pass_reg;
    private TextView tv_nick_reg;
    private TextView tv_youjian_reg;
    
    
    private  ProgressDialog progressDialog; 


    Boolean sexflag=true;//男
    int  userage=16;//16岁
      Handler ResHandler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            Bundle bd = msg.getData();
            switch (bd.getInt("key")) {
                case 0:
                    progressDialog
                            = new ProgressDialog( Register.this);
                    progressDialog.setIcon(R.mipmap.ic_launcher);
                    progressDialog.setTitle("等待");
                    progressDialog.setMessage("正在注册....");
                    progressDialog.show();
                    progressDialog.setCanceledOnTouchOutside(false);
                  
                    final String  number=  edt_phonenumber.getText().toString();
                    final String  pass=  edt_password.getText().toString();
                    final String  nick=  edt_nick.getText().toString();
                    final String  youjian= edt_youjian.getText().toString();
                    
                    final RexResult regexResult=BaseUtil.regexUser( number, pass, nick, youjian);
                    if(regexResult!=null&&!regexResult.isResult()){
                        progressDialog.setTitle("错误！");
                        String errorstring="";
                       
                        if(regexResult.getErrorNumberString()!=null){
                            errorstring+="* "+regexResult.getErrorNumberString()+"\n";
                        }
                        if(regexResult.getErrorPassString() !=null){
                            errorstring+="* "+regexResult.getErrorPassString()+"\n";
                        }
                        if(regexResult.getErrorNikeString()!=null){
                            errorstring+="* "+regexResult.getErrorNikeString()+"\n";
                        }
                        if(regexResult.getErrorYouJianString()!=null){
                            errorstring+="* "+regexResult.getErrorYouJianString()+"\n";
                        }
                        progressDialog.setMessage(errorstring);
                    } ;
                    BmobIMApplication.serviceThreadPool.submit(new Runnable()
                    {

                        @Override
                        public void run()
                        {
                            try {
                                if(regexResult!=null&&!regexResult.isResult()){
                                    Thread.sleep(3000);
                                }else{
                                  
                                    final MyUser myuser = new MyUser();
                                    myuser.setUsername(number);
                                    myuser.setPassword(pass);
                                    myuser.setAge(userage);
                                    myuser.setNick(nick);
                                    myuser.setSex(sexflag);
                                    myuser.setPower(1);
                                    myuser.setMobilePhoneNumber(number);
                                    myuser.setEmail(youjian.trim());
                                    myuser.setIsline(false);
                                   //注册
                                    doregister(myuser,number,pass);
                                    
                                    
                                 
 
                                    Thread.sleep(4000);
                                }


                            }
                            catch (Exception
                                    e) {

                            }
                            finally{
                                if (!Register.this.isFinishing()) {
                                    progressDialog.dismiss();
                                    btn_register_reg.setEnabled(true);
                                }

                            }
                        }

                        
                    }) ;
                   
                    break;
                case 1:
                    break;
             }
        }
    };
     


    private void createUserInfo(UserInfo userInfo, final MyUser myuser , final ChengShiNE mChengShiNE,
                                final String number, final String pass) {
        userInfo .save(new SaveListener<String>() {

            @Override
            public void done(String objectId, BmobException e) {
                if(e==null){
                    myuser.setUserInfoObjID(objectId);
                    progressDialog.setMessage("初始化用户信息成功:");
  
                }else{
                    progressDialog.setMessage("初始化用户信息失败！="+  BaseUtil.ErrorInfoString(e.getErrorCode()));
                    //dologin(number,pass);
                }
                doChengShiNE(  myuser , mChengShiNE,   number,   pass);
            }
        });
    }

    private void doChengShiNE( final MyUser myuser ,final ChengShiNE mChengShiNE, final String number, final String pass) {
        BmobQuery<ChengShiNE> query = new BmobQuery<ChengShiNE>();
//查询playerName叫“比目”的数据
        query.addWhereEqualTo("username", number);
//返回50条数据，如果不加上这条语句，默认返回10条数据
        query.setLimit(1);
//执行查询方法
        query.findObjects(new FindListener<ChengShiNE>() {
            @Override
            public void done(List<ChengShiNE> object, BmobException e) {
                if(e==null){
                    // 已存在
                    if(object!=null&&object.size()==1){
                        ChengShiNE mzChengShiNE= object.get(0);
//                      //  updateChengShine(  myuser ,mzChengShiNE , mChengShiNE,
//                                number,   pass);
                        progressDialog.setMessage("诚信信息已存在！="+  BaseUtil.ErrorInfoString(e.getErrorCode()));
                        dologin(number,pass);
                    }else{
                        // 不存在
                        createChengShine(  myuser , mChengShiNE,
                                number,   pass);
                    }

                }else{
                    // 不存在
                    createChengShine(  myuser , mChengShiNE,
                            number,   pass);
                }
            }


        });
    }

    private void updateChengShine(final MyUser myuser , ChengShiNE mzmChengShiNE, ChengShiNE mChengShiNE, final String number, final String pass) {
        mChengShiNE.update(mzmChengShiNE.getObjectId(), new UpdateListener() {

            @Override
            public void done(BmobException e) {
                if(e==null){
                    doregister(myuser,number,pass);
                }else{
                    progressDialog.setMessage("更新诚信信息失败！="+  BaseUtil.ErrorInfoString(e.getErrorCode()));
                   // Log.i("bmob","更新失败："+e.getMessage()+","+e.getErrorCode());
                }
            }

        });
    }

    private void createChengShine(  final MyUser myuser ,final ChengShiNE mChengShiNE,
                                   final String number, final String pass) {
        mChengShiNE.save(new SaveListener<String>() {

            @Override
            public void done(String objectId, BmobException e) {
                if(e==null){
                    //toast("创建数据成功：" + objectId);
                    myuser.setChengShiNEObjID(objectId);
                    progressDialog.setMessage("初始化诚信成功:");
                    //注意：不能用save方法进行注册
                  //  doregister(myuser,number,pass);
                   

                }else{
                    progressDialog.setMessage("初始化用户诚信失败！="+  BaseUtil.ErrorInfoString(e.getErrorCode()));
                    //Log.i("bmob","失败："+e.getMessage()+","+e.getErrorCode());
                 
                }
                dologin(number,pass);
            }
        });
    }
    private void doregister( final MyUser myuser ,final String number, final String pass) {
        myuser.signUp(new SaveListener<MyUser>() {
            @Override
            public void done(MyUser s, BmobException e) {
                if(e==null){
                  
                    final UserInfo userInfo=new  UserInfo();
                    userInfo.setUsername(number);
                    userInfo.setMyuser(myuser);

                    final ChengShiNE mChengShiNE=new  ChengShiNE();
                    mChengShiNE.setUsername(number);
                    mChengShiNE.setPj(10);//品阶 平民
                    mChengShiNE.setH(false);//黑名单
                    if(sexflag==true){
                        mChengShiNE.setNumber(41);
                    }else{
                        mChengShiNE.setNumber(40);//诚信值
                    }
                    mChengShiNE.setSum(0);//积分
                    //添加一对一关联
                    mChengShiNE.setMyuser(myuser);





                    BmobQuery<UserInfo> query = new BmobQuery<UserInfo>();
//查询playerName叫“比目”的数据
                    query.addWhereEqualTo("username", number);
//返回50条数据，如果不加上这条语句，默认返回10条数据
                    query.setLimit(1);
//执行查询方法
                    query.findObjects(new FindListener<UserInfo>() {
                        @Override
                        public void done(List<UserInfo> object, BmobException e) {
                            if(e==null){
                                // 已存在
                                if(object!=null&&object.size()==1){
                                    UserInfo mzUserInfo= object.get(0);
                                    progressDialog.setMessage("用户信息已存在！="+  BaseUtil.ErrorInfoString(e.getErrorCode()));
                                    doChengShiNE(  myuser , mChengShiNE,   number,   pass);
                                    //  updateUserInfo(  myuser ,   number,   pass,mChengShiNE,userInfo,mzUserInfo);
                                }else{
                                    // 不存在
                                    createUserInfo( userInfo,  myuser , mChengShiNE,
                                            number,   pass
                                    );
                                }


                            }else{
                                // 不存在
                                createUserInfo( userInfo,  myuser , mChengShiNE,
                                        number,   pass
                                );
                            }
                        }


                    });
                  
                }else{
                    progressDialog.setMessage("注册失败！="+  BaseUtil.ErrorInfoString(e.getErrorCode()));
               
                }
            }
        });

    }

   void dologin(String number , final String pass){
       progressDialog.setMessage("注册成功:");
       
       BmobUser.loginByAccount(number, pass, new LogInListener<MyUser>() {

           @Override
           public void done(MyUser user, BmobException e) {
               if(user!=null){
                   MyUser newUser=new MyUser();
                   newUser.setIsline(true);
                   newUser.update(user.getObjectId(), new UpdateListener() {

                       @Override
                       public void done(BmobException e) {
                           if(e==null){
                               SharedPreferences sp=getApplicationContext().getSharedPreferences("SP",MODE_PRIVATE);
                               SharedPreferences.Editor editor=sp.edit();
                               editor.putBoolean("LoginLineFlag",true);
                               editor.putString("pass",pass);
                               editor.commit();
                               Base.isNogin=true;
                               progressDialog.setMessage("用户登陆成功:");
                               BmobUser.fetchUserJsonInfo(new FetchUserInfoListener<String>() {
                                   @Override
                                   public void done(String s, BmobException e) {

                                   }
                               });
                               Intent it = new Intent(getBaseContext(), WorldActivity.class);
                               startActivity(it);
                               finish();
                           }else{
                               progressDialog.setMessage("在线状态修改失败！="+  BaseUtil.ErrorInfoString(e.getErrorCode()));
                           }
                       }

                   });

               }else{
                   progressDialog.setMessage("登陆失败！="+  BaseUtil.ErrorInfoString(e.getErrorCode()));

               }
           }
       });
   }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        tv_number_reg=     (TextView)findViewById(R.id.tv_number_reg);
        tv_pass_reg=     (TextView)findViewById(R.id.tv_pass_reg);
        tv_nick_reg=     (TextView)findViewById(R.id.tv_nick_reg);
        tv_youjian_reg=     (TextView)findViewById(R.id.tv_youjian_reg);
        
        edt_phonenumber=(EditText)findViewById(R.id.edt_phonenumber);
        edt_password=(EditText)findViewById(R.id.edt_password);
        edt_nick=(EditText)findViewById(R.id.edt_nick);
        edt_youjian=(EditText)findViewById(R.id.edt_youjian);

        tv_sex=     (TextView)findViewById(R.id.tv_sex);
        tv_sex.setText("性别:男");
         switch_sex=(Switch)findViewById(R.id.switch_sex);
        switch_sex. setOnCheckedChangeListener(new Switch.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {
                // TODO Auto-generated method stub  
                if (isChecked) {
                    tv_sex.setText("性别:女");
                    sexflag=false;
                } else {
                    tv_sex.setText("性别:男");;// 关闭蓝牙  
                    sexflag=true;
                }
            }
        });
        tv_age=     (TextView)findViewById(R.id.tv_age);  
        tv_age.setText("年龄："+16+"岁");
        
           seekBar_age=(SeekBar)findViewById(R.id.seekBar_age);
        // 设置拖动条改变监听器  
        seekBar_age.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            // 停止拖动的时候调用  
            @Override
            public void onStopTrackingTouch(SeekBar arg0) {
             //  int age = arg0.getProgress()+16;
               // tv_age.setText("年龄："+age+"岁");
            }

            // 开始拖动时调用  
            @Override
            public void onStartTrackingTouch(SeekBar arg0) {
                // tv_age.setText("开始调节");

            }

            // 显示的是当前的进度  
            @Override
            public void onProgressChanged(SeekBar arg0, int arg1, boolean arg2) {
                int age = arg0.getProgress()+16;
                tv_age.setText("年龄："+age+"岁");
                userage=age;
            }
        });
        btn_register_reg   =  (Button)findViewById(R.id.btn_register_reg);
        btn_register_reg.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_register_reg:
                btn_register_reg.setEnabled(false);
                BaseUtil.sendhandlermessage(ResHandler,false,0,"");
                break;
        }
    }
}
