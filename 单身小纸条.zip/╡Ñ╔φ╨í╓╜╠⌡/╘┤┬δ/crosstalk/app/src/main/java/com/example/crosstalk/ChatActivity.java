package com.example.crosstalk;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.crosstalk.Adapter.ChatHisAdapter;
import com.example.crosstalk.DAO.MSqliteUtil;
import com.example.crosstalk.LocalEnty.ChatHistory;
import com.example.crosstalk.LocalEnty.ChatObj;
import com.example.crosstalk.NetEnty.MyUser;
import com.example.crosstalk.NetEnty.TwoP;
import com.example.crosstalk.util.Base;
import com.example.crosstalk.util.BaseUtil;
import com.example.crosstalk.util.TimeUtil;
import com.example.crosstalk.util.ViewMyUtil;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.bmob.v3.BmobInstallation;
import cn.bmob.v3.BmobInstallationManager;
import cn.bmob.v3.BmobPushManager;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.PushListener;
import cn.bmob.v3.listener.QueryListener;
import cn.bmob.v3.listener.UpdateListener;

public class ChatActivity extends Base implements View.OnClickListener{
    int Show_ObjChatHistory_Count=6;
    ProgressDialog progressDialog = null;
    String[] from={"username","time","msg"};
    int[] to={R.id.chat_item_username,R.id.chat_item_time,R.id.chat_item_msg};

    ChatHisAdapter mChatHisAdapter;
    String objId_objname=null;
    boolean isplb=true;
    String objId_objNick;
Handler mChatHandler =new Handler(){
    @Override
    public void handleMessage(Message msg) {
        Bundle bd = msg.getData();
        switch (bd.getInt("key")) {
            case 0:
                progressDialog
                        = new ProgressDialog(ChatActivity.this);
                progressDialog.setIcon(R.mipmap.ic_launcher);
                progressDialog.setTitle("请等待");
                progressDialog.setMessage("正在连接加载....");
                progressDialog.setCanceledOnTouchOutside(false);
                progressDialog.show();
               

                String  msginfo=(String)msg.obj;
                BmobQuery<TwoP> query = new BmobQuery<TwoP>();
                query.getObject(msginfo, new QueryListener<TwoP>() {

                    @Override
                    public void done(final TwoP objectTwoP, BmobException e) {
                        if(e==null){
                            TwoP newTwoP=new TwoP();
                            newTwoP.setReaded(true);
                            newTwoP.update(objectTwoP.getObjectId(),new UpdateListener() {

                                @Override
                                public void done(BmobException e) {
                                    if(e==null){
                                        objInstallationId=  objectTwoP.getInstallationId();
                                       objId_objname=objectTwoP.getUsername();
                                        objId_objNick= objectTwoP.getNick();
                                        progressDialog.setMessage("成功捡起！");
                                    
                                    int count=MSqliteUtil.queryChatObj(objectTwoP.getUsername() ,progressDialog);
//                                        Toast.makeText(ChatActivity.this,"world_to_ChatObj_count:"+count,Toast.LENGTH_LONG).show();
                                        //判断 历史回话是否存在过这个对象
                                     if(count>0){
                                         //存在  
                                         //将这条消息 插入聊天历史数据库
                                         showChatHistory(  objectTwoP , objInstallationId
                                                 , progressDialog );
                                     }else if(count==0){
                                         //  不存在
                                         // 创建该回合 插入对象数据表
                                         ChatObj newChatObj=new ChatObj();
                                         newChatObj.setIsread(1);
                                         newChatObj.setObjname(objectTwoP.getUsername());
                                         
                                         newChatObj.setNick(objectTwoP.getNick());
                                         
                                         newChatObj.setTimemil(objectTwoP.getTime());
                                         BmobIMApplication.getReadlockCustom().writeLock().lock();
                                         try {
                                             newChatObj.saveThrows();
                                         } catch (Exception ex) {
                                             progressDialog.setMessage("本地异常！本地存储聊天对像失败");
                                         }finally{
                                             BmobIMApplication.getReadlockCustom().writeLock().unlock();
                                         }
                                         showChatHistory(  objectTwoP , objInstallationId
                                                 , progressDialog );
                                         //成功 //将这条消息 插入聊天历史数据库
                                         //成功//显示在界面上
                                     }else{
                                         //异常
                                         progressDialog.setMessage("异常");
                                     }     
                                           
                                             
                                          
                                              
                                        
//                                        BmobQuery<MyUser> query = new BmobQuery<MyUser>();
////查询playerName叫“比目”的数据
//                                        query.addWhereEqualTo("username",objectTwoP.getUsername());
////返回50条数据，如果不加上这条语句，默认返回10条数据
//                                        query.setLimit(1);
////执行查询方法
//                                        query.findObjects(new FindListener<MyUser>() {
//                                            @Override
//                                            public void done(List<MyUser> object, BmobException e) {
//                                                if(e==null){
//                                                    if(object!=null && object.size()==1){
//                                                        MyUser objuser=object.get(0);
//                                                        String nick=objuser.getNick();
//                                                        boolean sex=objuser.getSex();
//                                                        int  age=objuser.getAge();
//                                                        int power=objuser.getPower();
//                                                    }else{
//                                                        progressDialog.setMessage("查询用户失败！无该用户");
//                                                    }
//                                                   
//                                                }else{
//                                                    progressDialog.setMessage("查询用户失败！网络异常或者未知异常！");
//                                                }
//                                            }
//                                        });
                                    }else{
                                        progressDialog.setMessage("捡起失败！网络异常或者未知异常！");
                                    }
                                }
                            });
                        }else{
                            progressDialog.setMessage("读取失败！网络异常或者未知异常！");
                       
                        }
                    }

                });
              
                break;
            case 1:
                progressDialog
                        = new ProgressDialog(ChatActivity.this);
                progressDialog.setIcon(R.mipmap.ic_launcher);
                progressDialog.setTitle("请等待");
                progressDialog.setMessage("正在连接加载....");
                progressDialog.setCanceledOnTouchOutside(false);
                progressDialog.show();
              
                String  Cobjname=(String)msg.obj;
                ArrayList<ChatHistory> jtes=  MSqliteUtil.queryChat_ObjChatHistory(Cobjname,progressDialog,Show_ObjChatHistory_Count);
//                ArrayList<ChatHistory> jtes=null;
//                try {
//                    jtes = (ArrayList<ChatHistory>) DataSupport.where("objnames=? and isread=?",objname, 0+"").find(ChatHistory.class);
//                }catch (Exception e){
//                    progressDialog.setTitle("异常");
//                    progressDialog.setMessage("查询历史数据表失败.");
//                }
                if(jtes!=null && jtes.size()>=1){
                    progressDialog.setMessage(" 正加载...."+jtes.size()+"条记录");
                }else{
                    progressDialog.setMessage(" 无历史记录....");
                    return;
                }
                  ChatHistory  toObj= MSqliteUtil.queryhisChatHistory(Cobjname,progressDialog);
                 objInstallationId=toObj.getInstallationId();
                  mChatHisAdapter=new ChatHisAdapter(mLayoutInflater,ChatActivity.this,getData(jtes),R.layout.chat_item_my_item,from,to);
                chat_his.setAdapter(mChatHisAdapter);
                BmobIMApplication.serviceThreadPool.submit(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            ((ChatHisAdapter) chat_his.getAdapter())
                                    .notifyDataSetChanged();
                        } catch (Exception e) {
                        }
                    }
                });
                chat_his.setSelection(chat_his.getAdapter()
                        .getCount() - 1);
                progressDialog.dismiss();
                break;
            case 2:
                 String toobjname=(String) msg.obj;
                    ArrayList<ChatHistory> upjtes=  MSqliteUtil.queryChat_ObjChatHistory(toobjname,progressDialog,Show_ObjChatHistory_Count);
                if(upjtes!=null && upjtes.size()>=1){
                    progressDialog.setMessage(" 正加载...."+upjtes.size()+"条记录");
                }else{
                    progressDialog.setMessage(" 无历史记录....");
                    return;
                }
                    mChatHisAdapter=new ChatHisAdapter(mLayoutInflater,ChatActivity.this,getData(upjtes),R.layout.chat_item_my_item,from,to);
                    chat_his.setAdapter(mChatHisAdapter);
                chat_his.setSelection(chat_his.getAdapter()
                        .getCount() - 1);
                    BmobIMApplication.serviceThreadPool.submit(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                ((ChatHisAdapter) chat_his.getAdapter())
                                        .notifyDataSetChanged();
                              
                            } catch (Exception e) {
                            }
                        }
                    });
               
                    if(progressDialog!=null){
                        progressDialog.dismiss();
                    }
                
              
            
                break;
            case 3:
               ChatHistory mChatHistory=(ChatHistory) msg.obj;
                HashMap<String, String> mhs = new HashMap<String, String>();
//                             ChatHistory hbd = jtes.get(i);
                int mtype= mChatHistory.getType();
             
                    mhs.put(from[0], mChatHistory.getNick());
    
              //  hs.put(from[0], mChatHistory.getObjnames());
                mhs.put(from[1], mChatHistory.getTime()+"");
                mhs.put(from[2], mChatHistory.getMsginfo());
                mhs.put("type", mChatHistory.getType()+"");

                mlist.add(mhs);
                if(mlist.size()>5){
                    mlist.remove(0);
                }
             
              
//                if(mtype==1){

                    chat_his.setSelection(chat_his.getAdapter()
                            .getCount() - 1);

//                }
                BmobIMApplication.serviceThreadPool.submit(new Runnable() {
                    @Override
                    public void run() {
                        try {
//                          
                            ((ChatHisAdapter) chat_his.getAdapter())
                                    .notifyDataSetChanged();
                           
                        } catch (Exception e) {
                        }
                    }
                });
                if(progressDialog!=null){
                    progressDialog.dismiss();
                }
            
                break;
        }
    }
};

    private void showChatHistory(TwoP objectTwoP ,String objInstallationId
    ,ProgressDialog progressDialog ) {
        ChatHistory mChatHistory=new ChatHistory();
        mChatHistory.setObjnames(objectTwoP.getUsername());
      
        mChatHistory.setNick(objectTwoP.getNick());
      
        mChatHistory.setInstallationId(objInstallationId);
        mChatHistory.setIsread(1);

        mChatHistory.setMsginfo(objectTwoP.getMsg());
        mChatHistory.setTime(TimeUtil.getTimemili());//接受时间
        mChatHistory.setType(1);//obj
        BmobIMApplication.getReadlockCustom().writeLock().lock();
        try {
            mChatHistory.saveThrows();
        } catch (Exception ex) {
            progressDialog.setMessage("本地异常！本地存储对话失败");
        }finally{
            BmobIMApplication.getReadlockCustom().writeLock().unlock();
        }
        String toObjName=objectTwoP.getUsername();
        //成功  //显示在界面上
        BaseUtil.sendhandlermessage(mChatHandler,false,2,toObjName);
    }

    ArrayList<Map<String, String>> mlist = new ArrayList<Map<String, String>>();
    private List<? extends Map<String,?>> getData(ArrayList<ChatHistory> jtes) {
        int count = jtes.size();
        for (int i = count-1; i>=0; i--) {
            HashMap<String, String> hs = new HashMap<String, String>();
            ChatHistory hbd = jtes.get(i);
            hs.put(from[0], hbd.getNick());
           // hs.put(from[0], hbd.getObjnames());
            hs.put(from[1], hbd.getTime()+"");
            hs.put(from[2], hbd.getMsginfo());
            hs.put("type", hbd.getType()+"");
            
            mlist.add(hs);
        }
        return mlist;
    }

    ListView chat_his;
    EditText chat_txt;
    Button chat_send;

    String   objId;
    String objname=null;
    LayoutInflater mLayoutInflater;
    String  objInstallationId=null;
    BmobUser mUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        Intent it=getIntent();
          objId=it.getStringExtra("objId");
          objname=it.getStringExtra("objname");
        mLayoutInflater=  this.getLayoutInflater();
        chat_his=(ListView)findViewById(R.id.chat_his);
        mUser=BmobUser.getCurrentUser(MyUser.class);
        chat_his.setEnabled(false);
        chat_txt=(EditText)findViewById(R.id.chat_txt);
        chat_send=(Button)findViewById(R.id.chat_send);
        chat_send.setOnClickListener(this);
//        new KeyboardChangeListener(this).setKeyBoardListener(new KeyboardChangeListener.KeyBoardListener() {
//            @Override
//            public void onKeyboardChange(boolean isShow, int keyboardHeight) {
//                 
//                chat_his.setSelection(chat_his.getBottom());
//            }
//            
//        });
    }
   
    ChatBroadcastReceiver mChatBroadcastReceiver=null;
    IntentFilter mintentFilter=null;
   
    @Override
    protected void onResume() {
        super.onResume();
        //注册广播接收器
       
        mChatBroadcastReceiver = new ChatBroadcastReceiver() ;
        mintentFilter = new IntentFilter(BmobIMApplication.updateViewAction) ;
        if(BmobIMApplication.localBroadcastManager!=null&& mChatBroadcastReceiver!=null&& mintentFilter!=null){
            BmobIMApplication.localBroadcastManager.registerReceiver( mChatBroadcastReceiver , mintentFilter );
        }
       
        if(mlist!=null)
        {
            mlist.clear();
        }
        if(objId!=null){
            isplb=true;
            BaseUtil.sendhandlermessage(mChatHandler,false,0,objId);
//            Toast.makeText(ChatActivity.this,"objid:"+objId,Toast.LENGTH_SHORT).show();
        }
        if(objname!=null){
            isplb=false;
              BaseUtil.sendhandlermessage(mChatHandler,false,1,objname);
//            Toast.makeText(ChatActivity.this,"objname:"+objname,Toast.LENGTH_SHORT).show();
        }
    }
    private class ChatBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction() ;
            if ( BmobIMApplication.updateViewAction.equals( action )){
                ChatHistory mReceiverChatHistory=new ChatHistory();
                Bundle bd=intent.getExtras();
                mReceiverChatHistory.setObjnames(bd.getString("username"));
                mReceiverChatHistory.setMsginfo(bd.getString("infomsg"));
                mReceiverChatHistory.setInstallationId(bd.getString("obj_InstallationId"));
                mReceiverChatHistory.setTime(bd.getLong("Time"));
                mReceiverChatHistory.setIsread(bd.getInt("Isread"));
                mReceiverChatHistory.setType(bd.getInt("Type"));
             
                mReceiverChatHistory.setNick(bd.getString("nick"));
                
//                Toast.makeText(ChatActivity.this,"bd!+null:username:"+mReceiverChatHistory.getObjnames(),Toast.LENGTH_LONG).show();
                //局部刷新
                BaseUtil.sendhandlermessage(mChatHandler,false,3,mReceiverChatHistory);
              
//                // 更新ui
//                //显示在界面上
//                
//                if(isplb){
//                    BaseUtil.sendhandlermessage(mChatHandler,false,2,objId_objname);
//                }else{
//                    BaseUtil.sendhandlermessage(mChatHandler,false,2,objname);
//                }
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        //取消注册广播,防止内存泄漏
        if(BmobIMApplication.localBroadcastManager!=null&&mChatBroadcastReceiver!=null){
            BmobIMApplication.localBroadcastManager.unregisterReceiver( mChatBroadcastReceiver );
        }
       
        
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.chat_send:
                progressDialog= ViewMyUtil.get_progressDialog_set(
                        ChatActivity.this,
                        R.mipmap.ic_launcher,
                        "请等待",
                        "正在连接加载....",
                        false 
                 );
//                progressDialog
//                        = new ProgressDialog(ChatActivity.this);
//                progressDialog.setIcon(R.mipmap.ic_launcher);
//                progressDialog.setTitle("请等待");
//                progressDialog.setMessage("正在连接加载....");
//                progressDialog.setCanceledOnTouchOutside(false);
//                progressDialog.show();
                //TODO 替换成所需要推送的Android客户端installationId
                BmobPushManager bmobPushManager = new BmobPushManager();
                BmobQuery<BmobInstallation> query = BmobInstallation.getQuery();
             if(objInstallationId!=null&&!objInstallationId.trim().equalsIgnoreCase("")){
                 query.addWhereEqualTo("installationId", objInstallationId);
                 bmobPushManager.setQuery(query);
                 final MyUser muser= BmobUser.getCurrentUser(MyUser.class);
                 final long mTime= TimeUtil.getTimemili();
                 final String mInstallationId=  BmobInstallationManager.getInstallationId();
                 final String msg= chat_txt.getText().toString();
                 if(msg!=null&&!msg.trim().equals("")&&msg.trim().length()>2){
                     
                
                // 1发送人名2 发送人设备号 3时间 4信息
                 JSONObject mJSONArray= new JSONObject();
                 try {
                     mJSONArray.put("InstallationId",mInstallationId);
                     mJSONArray.put("msg",msg);
                 
                  
                     mJSONArray.put("time",mTime);
                     mJSONArray.put("username",muser.getUsername());
                     mJSONArray.put("nick",muser.getNick());
                 }catch (Exception e){
                     progressDialog.setMessage("信息编码失败");
                     return;
                 }
              
                 bmobPushManager.pushMessage(mJSONArray+"", new PushListener() {
                     @Override
                     public void done(BmobException e) {
                         if (e == null) {
                             //Logger.e("推送成功！");
                             //保存为历史记录
                             chat_txt.setText("");
                             ChatHistory mChatHistory=new ChatHistory();
                             if(isplb){
                                 mChatHistory.setObjnames(objId_objname);   
                             }else{
                                 mChatHistory.setObjnames(objname);
                             }
                             mChatHistory.setInstallationId(mInstallationId);
                             mChatHistory.setIsread(1);
                            
                             mChatHistory.setMsginfo(msg);
                             mChatHistory.setTime(mTime);
                             mChatHistory.setType(0);//my
                             mChatHistory.setNick(muser.getNick());
                             BmobIMApplication.getReadlockCustom().writeLock().lock();
                             try {
                                 mChatHistory.saveThrows();
                             } catch (Exception ex) {
                                 progressDialog.setMessage("本地异常！本地存储对话失败");
                             }finally{
                                 BmobIMApplication.getReadlockCustom().writeLock().unlock();
                             }
                             //局部刷新
                             BaseUtil.sendhandlermessage(mChatHandler,false,3,mChatHistory);
                             closeKeyboard();
//                             HashMap<String, String> hs = new HashMap<String, String>();
////                             ChatHistory hbd = jtes.get(i);
//                             hs.put(from[0], mChatHistory.getObjnames());
//                             hs.put(from[1], mChatHistory.getTime()+"");
//                             hs.put(from[2], mChatHistory.getMsginfo());
//                             hs.put("type", mChatHistory.getType()+"");
//
//                             mlist.add(hs);
//                             //整个刷新
//                             if(mlist!=null)
//                             {
//                                 mlist.clear();
//                             }
//                              //显示在界面上
//                             if(isplb){
//                                 BaseUtil.sendhandlermessage(mChatHandler,false,2,objId_objname);
//                             }else{
//                                 BaseUtil.sendhandlermessage(mChatHandler,false,2,objname);
//                             }
                          
                         } else {
                             //  Logger.e("异常：" + e.getMessage());
                             progressDialog.setMessage("异常！发送失败，检测网络异常或未知");
                             //提示发送失败
                         }
                         }
                 });
                 }else{

                     Toast.makeText(ChatActivity.this,
                             "信息不能为空且 大于2个字符",
                             Toast.LENGTH_SHORT).show();

                 }
             }else{
                 progressDialog.setMessage("无法找到此设备");
                 //  Logger.e("无法找到此设备：" + e.getMessage());
             }
                //progressDialog.dismiss();
                break;
        }
    }

//    private ProgressDialog get_progressDialog_set(Context mContext,int Micon,
//                                                  String mTitle,String mMessage,
//                                                  Boolean isCanceledOnTouchOutside) {
//        progressDialog
//                = new ProgressDialog(mContext);
//        progressDialog.setIcon(Micon); 
//        progressDialog.setTitle(mTitle);
//        progressDialog.setMessage(mMessage);
//        progressDialog.setCanceledOnTouchOutside(isCanceledOnTouchOutside);
//        progressDialog.show();
//    }
private void closeKeyboard() {
     InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
    imm.hideSoftInputFromWindow(chat_txt.getWindowToken(),0);
}
}
