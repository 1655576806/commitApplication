package com.example.crosstalk.LocalEnty;

import org.litepal.crud.DataSupport;

/**
 * Created by Administrator on 2017/9/12 0012.
 */

public class ChatHistory extends DataSupport {
    public  String  objnames ;// 聊天对象会话 账号

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public int getIsread() {
        return isread;
    }

    public String nick;
    public  int  type ;//谁说的1 obj  0 my
    public  String  msginfo;//说了什么
    public  long  time;//何时说的s
    public  int isread;//是否已经可读
    public  String InstallationId;//设备标示
    public String getInstallationId() {
        return InstallationId;
    }

    public void setInstallationId(String installationId) {
        InstallationId = installationId;
    }


    public String getObjnames() {
        return objnames;
    }

    public void setObjnames(String objnames) {
        this.objnames = objnames;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getMsginfo() {
        return msginfo;
    }

    public void setMsginfo(String msginfo) {
        this.msginfo = msginfo;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public int isread() {
        return isread;
    }

    public void setIsread(int isread) {
        this.isread = isread;
    }
}
