package com.example.crosstalk.util;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;

import java.util.List;

import cn.bmob.v3.datatype.BmobGeoPoint;

/**
 * Created by Administrator on 2017/9/11 0011.
 */

public class MBmobutil {
    
    public static BmobGeoPoint getlocation(Context context) {
        //获取地理位置管理器  
        LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        //获取所有可用的位置提供器  
        List<String> providers = locationManager.getProviders(true);
        String locationProvider;
        if (providers.contains(LocationManager.GPS_PROVIDER)) {
            //如果是GPS  
            locationProvider = LocationManager.GPS_PROVIDER;
        } else if (providers.contains(LocationManager.NETWORK_PROVIDER)) {
            //如果是Network  
            locationProvider = LocationManager.NETWORK_PROVIDER;
        } else {

            return null;
        }
        //获取Location  
        Location location = null;
        try {
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return null;
            }
            location = locationManager.getLastKnownLocation(locationProvider);
        }catch (Exception e){
            
        }finally {
            if(location!=null){
                BmobGeoPoint map=new BmobGeoPoint();
                map.setLatitude(location.getLatitude());
                map.setLongitude(location.getLongitude());
                
                return map;
            }else{
                return null;
            }
        }
      
        
       
        //监视地理位置变化  
       //locationManager.requestLocationUpdates(locationProvider, 3000, 1, locationListener);

    };
 
}
