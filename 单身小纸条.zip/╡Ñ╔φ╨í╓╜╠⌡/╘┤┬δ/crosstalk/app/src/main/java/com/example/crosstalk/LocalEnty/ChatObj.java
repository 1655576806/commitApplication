package com.example.crosstalk.LocalEnty;

import org.litepal.crud.DataSupport;

/**
 * Created by Administrator on 2017/9/12 0012.
 */

public class ChatObj extends DataSupport {
    private  String  objname;//唯一回话  账号
    private  int  isread;//可读性true
    private  long  timemil;//插入时间ms
    public String nick;
    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getObjname() {
        return objname;
    }

    public void setObjname(String objname) {
        this.objname = objname;
    }

    public int getIsread() {
        return isread;
    }

    public void setIsread(int isread) {
        this.isread = isread;
    }

    public long getTimemil() {
        return timemil;
    }

    public void setTimemil(long timemil) {
        this.timemil = timemil;
    }
}
