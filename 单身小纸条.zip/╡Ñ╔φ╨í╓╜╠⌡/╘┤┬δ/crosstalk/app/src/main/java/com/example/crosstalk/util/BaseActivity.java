package com.example.crosstalk.util;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;

import com.example.crosstalk.MainActivity;
import com.example.crosstalk.NetEnty.MyUser;
import com.example.crosstalk.R;
import com.example.crosstalk.TradeActivity;
import com.pgyersdk.feedback.PgyFeedback;
import com.pgyersdk.javabean.AppBean;
import com.pgyersdk.update.PgyUpdateManager;
import com.pgyersdk.update.UpdateManagerListener;

import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.UpdateListener;

import static cn.bmob.v3.BmobUser.getCurrentUser;


public class BaseActivity  extends AppCompatActivity {
	//CustomApplication cusp;
	String msSg = "已经是最新版本\t无需更新\t 官网:https://www.pgyer.com/zuqibifencelue";
	boolean fxflag = true;
	boolean isAccountRemovedDialogShow = false;
	AlertDialog.Builder accountRemovedBuilder;
	Activity act;
	boolean flag = true;
	boolean flags = true;
	Context basemcontext;
 
	@SuppressLint("NewApi") @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	//	cusp = new CustomApplication();
		basemcontext = this;
		
	}

	@SuppressLint("HandlerLeak")
	Handler basehandler = new Handler() {

		public void handleMessage(Message msg) {
			switch (msg.arg1)  {
				case 0:
                    MyUser bmobUser = getCurrentUser(MyUser.class);
					SharedPreferences sp=getApplicationContext().getSharedPreferences("SP",MODE_PRIVATE);
				   final 	SharedPreferences.Editor editor=sp.edit();
					boolean LoginLineFlag= sp.getBoolean("LoginLineFlag",false);
					//editor.putBoolean("LoginLineFlag",true);
                    if(LoginLineFlag&&bmobUser!=null){
						
                        MyUser newUser = new MyUser();
                        newUser.setIsline(false);
                        newUser.update(bmobUser.getObjectId(),new UpdateListener() {
                            @Override
                            public void done(BmobException e) {
								editor.putBoolean("LoginLineFlag",false);
								editor.putBoolean("autoFlag",false);
								editor.commit();
                                BmobUser.logOut();
								Intent intent = new Intent(getBaseContext(),
										MainActivity.class);
								startActivity(intent);
								finish();
                              
                            }
                        });
                    }
					
					break;
			}  
		};

	};
	ProgressDialog progressDialog;
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		AlertDialog.Builder as = null;
		switch (item.getItemId()) {
       case R.id.action_settings:
       	  MyUser user=  BmobUser.getCurrentUser(MyUser.class);
		   if(user!=null){
			   Intent intent = new Intent(getBaseContext(),
					   TradeActivity.class);
			   startActivity(intent);
		   }else{
			   progressDialog
					   = new ProgressDialog(BaseActivity.this);
			   progressDialog.setIcon(R.mipmap.ic_launcher);
			   //progressDialog.setTitle("提示");
			   progressDialog.setMessage("请先登录....");
			   progressDialog.show();
			   progressDialog.setCanceledOnTouchOutside(false);
			   try {
				   Thread.sleep(2000);
			   }catch (InterruptedException e){
				   
			   }finally {
				   progressDialog.dismiss();
			   }
			  
		   }
		  
 			break;
     	case R.id.action_tuchu:
//			isAccountRemovedDialogShow = true;
			if (!this.isFinishing()) {
				try {
					if (accountRemovedBuilder == null&&  this != null && ! this.isFinishing())
						accountRemovedBuilder = new android.app.AlertDialog.Builder(
								this );
					accountRemovedBuilder.setTitle("关闭");
					accountRemovedBuilder.setMessage("登出账号");
					accountRemovedBuilder.setNegativeButton ("确定",
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog,
													int which) {
									Message msg = new Message();
									msg.arg1 = 0;
									basehandler.sendMessage(msg);
									accountRemovedBuilder = null;
									dialog.dismiss();
								}
							});
					accountRemovedBuilder.setPositiveButton("否",
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog,
													int arg1) {
									dialog.dismiss();
								}
							});
					accountRemovedBuilder.setCancelable(false);
					accountRemovedBuilder.create().show();
				} catch (Exception e) {
				}

			}
      break;
// case R.id:
//			TextView img = new TextView(this);
//			img.setText("qq:1-7-5-8-2-3-3-1-8-9 \n" + "���䣺1758233189@qq.com \n"
//					+ "��ӭ����㱦����������");
//			if(  this != null && ! this.isFinishing()){
//			as = new AlertDialog.Builder(  this );
//			as.setView(img)
//					.setTitle("�����䣺")
//					.setPositiveButton("ȷ��",
//							new DialogInterface.OnClickListener() {
//								@Override
//								public void onClick(DialogInterface dialog,
//										int which) {
//
//									dialog.dismiss();
//								}
//							});
//
//			AlertDialog mAlertDialog = as.create();
//			mAlertDialog.setCanceledOnTouchOutside(false);
//			WindowManager.LayoutParams lp = mAlertDialog.getWindow()
//					.getAttributes();
//			lp.dimAmount = 1.0f;
//			mAlertDialog.getWindow().setAttributes(lp);
//			mAlertDialog.show();
//			}
//			break;
//		case R.id.action_wall:
//		///	AppConnect.getInstance(this).showOffers(this);
//			break;
 	case R.id.action_fankui:
 		PgyFeedback.getInstance().showDialog(this);
		break;
		case R.id.action_gengxin:
            
			PgyUpdateManager.register(this, "",  new UpdateManagerListener() {

				@Override
				public void onUpdateAvailable(final String result) {
					final AppBean appBean = getAppBeanFromString(result);
						msSg = appBean.getReleaseNote();
						if(   BaseActivity.this != null && ! BaseActivity.this.isFinishing()){
						new AlertDialog.Builder(BaseActivity.this )
						.setTitle("更新")
						.setMessage(msSg)
						.setPositiveButton("确定",
								new DialogInterface.OnClickListener() {

									@Override
									public void onClick(
											DialogInterface dialog,
											int which) {
											startDownloadTask(
													BaseActivity.this,
													appBean.getDownloadURL());
									}
								})
						.setNegativeButton("否",
								new DialogInterface.OnClickListener() {

									@Override
									public void onClick(
											DialogInterface dialog,
											int which) {
										dialog.dismiss();
									}
								}).show();
						}

				}

				@Override
				public void onNoUpdateAvailable() {
					if(   BaseActivity.this != null && ! BaseActivity.this.isFinishing()){
					new AlertDialog.Builder(BaseActivity.this )
					.setTitle("更新")
					.setMessage(msSg)
					.setPositiveButton("确定",
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(
										DialogInterface dialog,
										int which) {

									dialog.dismiss();
								}
							}).show();
				}}
			}) ;
			break;
		 
//		case R.id.action_jcmn:
//			Intent intent = new Intent(getBaseContext(),
//					JCMoniWBMainActivity.class);
//			startActivity(intent);
//			break;
 
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

 
	AlertDialog.Builder asS;
	AlertDialog mAlertDialog;

	@Override
	public void onBackPressed() {
        if(   BaseActivity.this != null && ! BaseActivity.this.isFinishing()){
            AlertDialog.Builder asS = new AlertDialog.Builder(BaseActivity.this );
            asS
                    .setTitle("退出" )
                    .setPositiveButton("否",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(
                                        DialogInterface dialog,
                                        int which) {
                                    dialog.dismiss();
                                }
                            }) ;
            asS.setNegativeButton("确定",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(
                                DialogInterface dialog,
                                int which) {
                            dialog.dismiss();
                            finish();
                        }
                    });
            AlertDialog mAlertDialog = asS.create();
            mAlertDialog.setCanceledOnTouchOutside(false);
            WindowManager.LayoutParams lp = mAlertDialog.getWindow()
                    .getAttributes();
            lp.dimAmount = 1.0f;
            mAlertDialog.getWindow().setAttributes(lp);
            mAlertDialog.show();
        }
    }
	//ʵ��ConnectionListener�ӿ�
		 
		 
	@Override
	protected void onPause() {
		super.onPause();
		// �岥���
		
		 
		 
	}

	@Override
	protected void onStop() {
		super.onStop();
		// �岥���
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		// �岥���
	}

	 
	
	
}
