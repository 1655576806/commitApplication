package com.example.crosstalk.util;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.example.crosstalk.MainActivity;
import com.example.crosstalk.NetEnty.MyUser;
import com.example.crosstalk.R;

import org.json.JSONObject;

import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobRealTimeData;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.ValueEventListener;


public class Base extends BaseActivity {
  public static   boolean  isNogin=false;
Handler baseHandler=new Handler(){
    @Override
    public void handleMessage(Message msg) {
        Bundle bd = msg.getData();
        switch (bd.getInt("key")) {
            case 0:
               // Toast.makeText(Base.this,"下线",Toast.LENGTH_SHORT).show();
           final   MyUser bmobUser = BmobUser.getCurrentUser(MyUser.class);
                SharedPreferences sp=getApplicationContext().getSharedPreferences("SP",MODE_PRIVATE);
                final 	SharedPreferences.Editor editor=sp.edit();
                boolean LoginLineFlag= sp.getBoolean("LoginLineFlag",false);
                //
                if(LoginLineFlag&&bmobUser!=null){
                    BmobQuery<MyUser> query = new BmobQuery<MyUser>();
                    query.addWhereEqualTo("username", bmobUser.getUsername());
                    query.findObjects(new FindListener<MyUser>() {
                        @Override
                        public void done(List<MyUser> object, BmobException e) {
                            if(e==null && object.size()==1){
                                  MyUser netMyUser=  (MyUser)object.get(0);
                                    if(! netMyUser.isline()) {
                                        isNogin = false;
                                        editor.putBoolean("LoginLineFlag",false).commit();
                                        editor.putBoolean("autoFlag", false).commit();
                                        Intent intent = new Intent(getBaseContext(),
                                                MainActivity.class);
                                        startActivity(intent);
                                        finish();

                                    }else{
                                        return;

                                    }                             
                            }else{
                                isNogin = false;
                                editor.putBoolean("LoginLineFlag",false).commit();
                                editor.putBoolean("autoFlag", false).commit();
                                Intent intent = new Intent(getBaseContext(),
                                        MainActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        }
                    });
                  
                  
                }else{
                    isNogin = false;
                    editor.putBoolean("LoginLineFlag",false).commit();
                    editor.putBoolean("autoFlag", false).commit();
                    Intent intent = new Intent(getBaseContext(),
                            MainActivity.class);
                    startActivity(intent);
                    finish();
                }
                break;
        }
    }
};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base);
    }
      BmobRealTimeData rtd = new BmobRealTimeData();
    String tableName="_User";
    @Override
    protected void onResume() {
        super.onResume();
      if(rtd!=null){
          rtd.start(new ValueEventListener() {
              @Override
              public void onDataChange(JSONObject data) {
                  //   Log.d("bmob", "("+data.optString("action")+")"+"数据："+data);
                  BaseUtil.sendhandlermessage(baseHandler,false,0,data);
              }

              @Override
              public void onConnectCompleted(Exception ex) {
                  //    Log.d("bmob", "连接成功:"+rtd.isConnected());
                  if(rtd.isConnected()){
                      MyUser user=    BmobUser.getCurrentUser(MyUser.class);
                      // 监听表更新
                      if(user!=null){

                          rtd.subRowUpdate(tableName,user.getObjectId()+"");
                      }

                  }
                  // 监听表更新
                  //  rtd.subTableUpdate(tableName);
// 监听表删除
                  //rtd.subTableDelete(tableName);
// 监听行更新

// 监听行删除
                  //rtd.subRowDelete(tableName, objectId);
              }
          });
      }
      
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 取消监听表更新
        //rtd.unsubTableUpdate(testTableName);
// 取消监听表删除
        //rtd.unsubTableDelete(testTableName);
// 取消监听行更新
        if(rtd!=null&&rtd.isConnected()){
            MyUser user=    BmobUser.getCurrentUser(MyUser.class);
            if(user!=null){
                rtd.unsubRowUpdate(tableName,user.getObjectId()+"");
            }
    
        }
         
// 取消监听行删除
      //  rtd.unsubRowDelete(testTableName, objectId);
    }
}
